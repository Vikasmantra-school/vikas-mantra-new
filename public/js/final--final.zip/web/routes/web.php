<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ZonesController;
use App\Http\Controllers\WeightsController;
use App\Http\Controllers\CountriesController;
use App\Http\Controllers\ImportExcelController;
use App\Http\Controllers\LocationController;

Route::get('/dashboard', function () {
    return view('admin.dashboard');
})->middleware(['auth'])->name('dashboard');

Route::group(['middleware' => ['auth']], function () {

	Route::get('/profile/', [WeightsController::class, 'profile']);
	Route::post('/profile/update/{id}', [WeightsController::class, 'profileUpdate']);
	Route::get('/profile/change-password', [WeightsController::class, 'changePassword']);
	Route::post('/profile/change-password-post', [WeightsController::class, 'changePasswordPost']);

	Route::get('/dashboard/services/dhl', [WeightsController::class, 'dhl']);
	Route::get('/dashboard/services/fedex', [WeightsController::class, 'fedex']);
	Route::get('/dashboard/services/ups', [WeightsController::class, 'ups']);
	Route::get('/dashboard/zones', [WeightsController::class, 'zones']);
	Route::get('/dashboard/locations', [LocationController::class, 'index']);

	Route::get('/locations', [LocationController::class, 'index']);
	Route::post('/location/create', [LocationController::class, 'store']);
	Route::post('/upload/file/ups', [ImportExcelController::class, 'import']);
	Route::post('/upload/file/dhl', [ImportExcelController::class, 'dhl']);
	Route::post('/upload/file/fdx', [ImportExcelController::class, 'fdx']);
	Route::post('/upload/file/zones', [ImportExcelController::class, 'zones']);
	Route::post('/upload/file/locations', [ImportExcelController::class, 'importLocations']);

	Route::get('/export/dhl', [ImportExcelController::class, 'exportDhl']);
	Route::get('/export/ups', [ImportExcelController::class, 'exportUps']);
	Route::get('/export/fedex', [ImportExcelController::class, 'exportFedex']);
	Route::get('/export/zones', [ImportExcelController::class, 'exportZones']);
	Route::get('/export/locations', [ImportExcelController::class, 'exportLocations']);


});

require __DIR__.'/auth.php';


Route::get('/', [WeightsController::class, 'index']);
Route::get('/about', [WeightsController::class, 'about']);
Route::get('/contact-us', [WeightsController::class, 'contact']);
Route::get('/services', function () {
    return view('pages.services');
});
Route::get('/faq', function () {
    return view('pages.faq');
});
Route::get('/upload', function () {
    return view('pages.upload');
});



Route::post('/test', [WeightsController::class, 'test']);
Route::post('/rates/{id}/{id2}/{id3}', [WeightsController::class, 'getRates']);

Route::get('/config-cache', function() {
    $exitCode = Artisan::call('config:cache');
});

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
});

Route::get('/forgot-password', function () {
    return view('auth.forgot-password');
})->middleware('guest')->name('password.request');

Route::get('/test/{id}/{id2}/{id3}', [WeightsController::class, 'getRatesTest']);


