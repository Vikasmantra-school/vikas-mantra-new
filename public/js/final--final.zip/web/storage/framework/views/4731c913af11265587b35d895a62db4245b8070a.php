<?php echo e($slot); ?>

<?php /**PATH /home/benfy/public_html/testing/deliveries/web/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>