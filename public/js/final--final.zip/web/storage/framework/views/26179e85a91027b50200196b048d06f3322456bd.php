    <?php $__env->startSection('content'); ?>

        <section class="pages-banner">
            <div class="section-lg section-header primary-bg" style="    padding-bottom: 83px;">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>Contact Us</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section section-lg">
            <div class="container contact">
                <div class="col-12 pb-3 message-box d-none">
                    <div class="alert alert-danger"></div>
                </div>
                <div class="row justify-content-around">
                    <div class="col-md-6">
                        <div class="contact-us-form bg-soft rounded p-5 contact-shadow">
                            <h4>Ready to get started?</h4>
                            <form action="/contact-us.php" method="POST" class="contact-us-form mt-4">
                                <div class="form-row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="name" placeholder="Enter name" required="required">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="email" class="form-control" name="email" placeholder="Enter email" required="required">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <textarea name="message" id="message" class="form-control" rows="7" cols="25" placeholder="Message"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 mt-3">
                                        <button type="submit" class="btn btn-secondary" id="btnContactUs" style="pointer-events: all; cursor: pointer;">
                                            Send Message
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-5 m-mt-20">
                        <div class="contact-us-content">
                            <h2>We partner with best business players.</h2>
                            <p>We at 3's Deliveries is a group of experienced logistics professionals, who have worked with the best of companies such as FedEx, UPS, Samsung, & Amazon. With an experience of over 20 years in the International and Domestic Logistics System in numerous areas ranging from International Express, Manufacturing to E-Commerce, Freight Forwarding, etc, we believe in providing the best services to meet our customers’ needs and provide them with complete logistics solutions.</p>


                            <hr class="my-5">

                            <h5>Head Office</h5>
                            <address>
                                3/14, Venkata Krishna Nagar, 2nd Street Arumbakkam<br/> Chennai 600106
                            </address>
                            <span>Phone: 7837775999</span> <br> 
                            <span>Email: <a href="mailto:ops3sdeliveries@gmail.com" class="link-color">ops3sdeliveries@gmail.com</a>,
                            <a href="mailto:customercare3sdeliveries@gmail.com" class="link-color">customercare3sdeliveries@gmail.com</a></span>

                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section section-lg locations bg-grayed">
            <div class="container">

                <div class="row">

                    <div class="col-sm-12 text-center addrss">
                        <h2>Our Address</h2>
                    </div>
                    
                </div>
                <div class="row loc-row">

                    <!-- <div class="col-md-12 loc-col">

                        <div class="row">

                            <div class="col-md-3">

                                <h2 class="user-circle">Sathish</h2>

                                <h4 class="header map">Address</h4>
                                <p>25-482, Sundharnagar, Reddigunta(p), Chittoor-517002</p>

                            </div>

                            <div class="col-md-3">

                                <h4 class="header train">Station Code</h4>
                                <p>Chittoor</p>

                                <h4 class="header location-arrow">Location</h4>
                                <p>13.178883,79.0943980</p>

                            </div>


                            <div class="col-md-3">

                                <h4 class="header user-shield">Supervisor Name</h4>
                                <p>jyothi</p>

                            </div>

                            <div class="col-md-3">

                                <h4 class="header phone-alt">Phone number</h4>
                                <a href="tel:9704671139"><p>9704671139</p></a>

                            </div>

                        </div>
                        
                    </div> -->

                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 loc-col"> 

                        <h2 class="user-circle"><?php echo e($location->name); ?></h2>

                        <h4 class="header map-marker-alt">Address</h4>
                        <p class="address-p"><?php echo e($location->address); ?></p>

                        <h4 class="header train">Station Code</h4>
                        <p><?php echo e($location->station_code); ?></p>

                        <h4 class="header location-arrow">Location</h4>
                        <p><?php echo e($location->location); ?></p>

                        <h4 class="header user-shield">Supervisor Name</h4>
                        <p><?php echo e($location->supervisor_name); ?></p>

                        <h4 class="header phone-alt">Phone number</h4>
                        <a href="tel:<?php echo e($location->phone_number); ?>"><p><?php echo e($location->phone_number); ?></p></a>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </div>
            </div>
        </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rene/Desktop/old/qs/resources/views/pages/contact.blade.php ENDPATH**/ ?>