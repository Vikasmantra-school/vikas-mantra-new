<?php $__env->startSection('content'); ?>

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">
                            <span>
                                <img src="/img/ups.jpeg" alt="UPS">
                            </span>
                            UPS
                        </h1> 
                        <a href="/export/ups" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Export Data</a>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">

                        <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/upload/file/ups')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="file-upload">
                                <button class="file-upload-btn" type="button" onclick="$('.file-upload-input').trigger( 'click' )">Browse Files</button>
                                <div class="image-upload-wrap">
                                    <input class="file-upload-input" id="upload_file" type="file" name="select_file" onchange="readURL(this);" />
                                    <div class="drag-text">
                                    <h3>Or Drag & Drop Xlsx here</h3>
                                    </div>
                                </div>
                                <div class="file-upload-content">

                                    <div class="upload_container">
                                        <p class="image-title mb-0"></p>
                                        <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                            Upload
                                            <i class="fas fa-upload fa-sm text-white-50"></i>
                                        </button>
                                    </div>

                                </div>
                            </div>

                        </form>

                        </div>
                    </div>


    <!-- Data -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">UPS Data</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>type</th>
                        <th>weight</th>
                        <th>zone_1</th>
                        <th>zone_2</th>
                        <th>zone_3</th>
                        <th>zone_4</th>
                        <th>zone_5</th>
                        <th>zone_6</th>
                        <th>zone_7</th>
                        <th>zone_8</th>
                        <th>zone_9</th>
                        <th>zone_10</th>
                        <th>zone_11</th>
                        <th>zone_12</th>
                        <th>zone_13</th>
                        <th>zone_14</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>type</th>
                        <th>weight</th>
                        <th>zone_1</th>
                        <th>zone_2</th>
                        <th>zone_3</th>
                        <th>zone_4</th>
                        <th>zone_5</th>
                        <th>zone_6</th>
                        <th>zone_7</th>
                        <th>zone_8</th>
                        <th>zone_9</th>
                        <th>zone_10</th>
                        <th>zone_11</th>
                        <th>zone_12</th>
                        <th>zone_13</th>
                        <th>zone_14</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $ups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($u->type); ?></td>
                        <td><?php echo e($u->weight); ?></td>
                        <td><?php echo e($u->zone_1); ?></td>
                        <td><?php echo e($u->zone_2); ?></td> 
                        <td><?php echo e($u->zone_3); ?></td>
                        <td><?php echo e($u->zone_4); ?></td>
                        <td><?php echo e($u->zone_5); ?></td>
                        <td><?php echo e($u->zone_6); ?></td>
                        <td><?php echo e($u->zone_7); ?></td>
                        <td><?php echo e($u->zone_8); ?></td>
                        <td><?php echo e($u->zone_9); ?></td>
                        <td><?php echo e($u->zone_10); ?></td>
                        <td><?php echo e($u->zone_11); ?></td>
                        <td><?php echo e($u->zone_12); ?></td>
                        <td><?php echo e($u->zone_13); ?></td>
                        <td><?php echo e($u->zone_14); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


                

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benfy/public_html/testing/deliveries/web/resources/views/admin/pages/ups.blade.php ENDPATH**/ ?>