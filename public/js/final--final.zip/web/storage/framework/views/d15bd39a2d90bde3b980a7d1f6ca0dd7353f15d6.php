<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create a Location!</h1>
                            </div>

                            <form class="user" method="post" action="/location/create">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" id=""
                                            placeholder="Name" name="name">
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" id=""
                                                placeholder="Station Code" name="station_code">
                                        </div>
                                        
                                    </div>
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" placeholder="Address" name="address">
                                </div>
                                
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" id=""
                                        placeholder="Location" name="location">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" id=""
                                        placeholder="Supervisor Name" name="supervisor_name">
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" id=""
                                        placeholder="Phone number" name="phone_number">
                                </div>
                              
                                 <button class="btn btn-primary btn-user btn-block" type="submit">
                                    Add Location
                                </button>

                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rene/Desktop/old/qs/resources/views/admin/locations.blade.php ENDPATH**/ ?>