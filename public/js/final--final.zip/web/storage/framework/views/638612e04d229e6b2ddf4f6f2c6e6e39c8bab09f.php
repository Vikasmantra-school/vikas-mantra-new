<!--team section start-->
   <section class="section section-sm feedback-section bg-grayed">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-lg-8">
               <div class="section-heading text-center mb-5">
                  <h3>Feedback</h3>
               </div>
            </div>
         </div>
         <div class="owl-carousel feedback">
            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Shiva Turlapati</h3>
                        <p class="card-text pt-4">The GDS team were thoroughly professional in their approach, offered prompt assistance and offered multiple options. Highly knowledgeable supply chain specialists!</p>
                        <!-- <p class="text-default small mt-5 mb-0"><b>Canadian Tire</b></p> -->
                     </div>
                  </div>
               </div>
            </div>
            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Ramya C</h3>
                        <p class="card-text pt-4">Hi Thank you for bringing my package safe.Everything was packed so neat especially the pickles.Wonderful service and keep up the good work.</p>
                        <!-- <p class="text-default small mt-5 mb-0"><b>Pepsi</b></p> -->
                     </div>
                  </div>
               </div>
            </div>
            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Veera Raghava Reddy</h3>
                        <p class="card-text pt-4">Service is very good and  very fast service and impressive. All the items were properly packed and ensured that there are no damages. Would prefer again and also recommend it.</p>
                        <!-- <p class="text-default small mt-5 mb-0"><b>Cineplex</b></p> -->
                     </div>
                  </div>
               </div>
            </div>

            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Victor Mendez</h3>
                        <p class="card-text pt-4">Transparent and easy to communicate. Every business needs things fast. The specialists at GDS were clear about the deadlines and provided us excellent support over the entire process.</p>
                        <!-- <p class="text-default small mt-5 mb-0"><b>Bombardier</b></p> -->
                     </div>
                  </div>
               </div>
            </div>

            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Lakshminarayana Osuri</h3>
                        <p class="card-text pt-4">Service is very good and very fast service and impressive - Wonderful service and keep up the good work.</p>
                        <!-- <p class="text-default small mt-5 mb-0"><b>Bombardier</b></p> -->
                     </div>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </section>
   <!--team section end-->
<?php /**PATH /Users/rene/Desktop/old/qs/resources/views/section/feedback.blade.php ENDPATH**/ ?>