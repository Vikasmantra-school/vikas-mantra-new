  <!--scroll bottom to top button start-->

  <button class="scroll-top scroll-to-target" data-target="html">

<span class="fas fa-hand-point-up"></span>

</button>

<!--scroll bottom to top button end-->

<!--build:js-->

<script src="/js/vendors/jquery-3.5.1.min.js"></script>

<script src="/js/vendors/popper.min.js"></script>

<script src="/js/vendors/bootstrap.min.js"></script>

<script src="/js/vendors/jquery.magnific-popup.min.js"></script>

<script src="/js/vendors/jquery.easing.min.js"></script>

<script src="/js/vendors/mixitup.min.js"></script>

<script src="/js/vendors/headroom.min.js"></script>

<script src="/js/vendors/smooth-scroll.min.js"></script>

<script src="/js/vendors/wow.min.js"></script>

<script src="/js/vendors/owl.carousel.min.js"></script>

<script src="/js/vendors/jquery.waypoints.min.js"></script>

<!--<script src="/js/vendors/countUp.min.js"></script>-->

<script src="/js/vendors/jquery.countdown.min.js"></script>

<script src="/js/vendors/validator.min.js"></script>

<script src="/js/app.js"></script>

<!--endbuild-->

<script type="text/javascript">
$(window).scroll(function() {    
  var scroll = $(window).scrollTop();

  if (scroll >= 500) {
      $(".float-btn .btn").removeClass("d-none");
  }
  else{
      $(".float-btn .btn").addClass("d-none");
  }

});
</script><?php /**PATH /Users/jerrysundar12/Desktop/benfy/quickship/resources/views/layouts/script.blade.php ENDPATH**/ ?>