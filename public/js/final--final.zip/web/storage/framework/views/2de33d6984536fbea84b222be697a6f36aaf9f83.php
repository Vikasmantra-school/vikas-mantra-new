<?php $__env->startSection('content'); ?>
<div class="main">
  <section class="pages-banner">
            <div class="section-lg section-header primary-bg" style="    padding-bottom: 83px;">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>FAQ's</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">FAQ's</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section section-sm">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-12">
                        <!--Accordion-->
                        <div class="accordion">
                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-1" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-1"><span class="h6 mb-0">Where all can YourShip India Pvt Ltd. ship my package?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-1">
                                    <div class="accordion-content">
                                        <p>Now with 3's Deliveries you can send your shipment easily, safely to any country in the world without burning a big hole in your pocket. YourShip India Pvt Ltd. provides cheapest, reliable, hassle free, door to door delivery services to 220+ countries around the world.</p>

                                    </div>
                                </div>
                            </div>
                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-2" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-2"><span class="h6 mb-0">How can I book my shipment?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-2">
                                    <div class="accordion-content">
                                        <p>You can simply select the origin, destination and weight to get the best discounted rates instantly from top carriers like DHL, Fedex, UPS & other cost effective private network. After selecting the carrier of your choice you can simply contact our customer support team via Call or Whatsapp or E-mail to schedule the pickup of your shipment.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">What documents do I need to book the shipment?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>You need to provide a copy of your Aadhar card and Pan card (as per the sender’s current address for the pickup) along with your shipment.</p>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <!--End of Accordion-->
                    </div>
                </div>
            </div>
        </section>
  
   
  
  
    <?php echo $__env->make('section.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
</div>
<div id="myModal" class="modal weight-c">
   <div class="modal-content">
      <div class="modal-header">
         <h3>Your Quote from India to <span id="destination"></span></h3>
         <span class="close">&times;</span>
      </div>
      <table>
         <tr class="tr-header">
            <th>Services</th>
            <th>Weight</th>
            <th>Charges</th>
            <th>Book your order</th>
         </tr>

         <tr>
            <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
            <td id="ups"></td>
            <td id="appendata"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
            <td id="dhl"></td>
            <td id="dhlRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
            <td id="fdx"></td>
            <td id="fdxRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

      </table>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benfy/public_html/testing/deliveries/quickship/resources/views/pages/faq.blade.php ENDPATH**/ ?>