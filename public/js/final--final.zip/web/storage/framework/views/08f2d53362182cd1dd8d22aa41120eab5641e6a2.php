<?php $__env->startSection('content'); ?>
<div class="main">
  <section class="pages-banner">
            <div class="section-lg section-header primary-bg" style="    padding-bottom: 83px;">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>About Us</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">About Us</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
  
   <!--about section start-->
   <section class="section">
      <div class="container">
         <div class="row justify-content-between align-items-center">
          
            <div class="col-md-12 col-lg-12">
               <div class="video-promo-content">
                  <h2>We Are The Bridge Between You And Your Relations</h2>

                  <p>3's Deliveries provides an end to end, seamless and hassle-free international logistics services which includes Air Door to Door International Courier services, Freight Forwarding, Customs clearance, Sea freight LCL & FCL and First and Last mile deliveries of products/shipments.</p>

                  <p>Under the leadership of experienced logistics professionals, the inception of 3's Deliveries has taken place. Leadership team has worked with blue chip companies like FedEx, UPS, Samsung & Amazon IN etc. and is carrying logistics experience of more than 20 years in International and domestic logistics in various areas ranging from International express, freight forwarding, manufacturing to E-commerce (retail) logistics business etc., 3's Deliveries has efficient team of expert professionals or SMEs who have designed the processes targeting customer needs and provide complete logistics solutions.</p>

                  <p>The team ensures timely delivery, cost effectiveness (we provide the best rates/ incentives as compared to prevailing players throughout the year) , customised solutions for individual customers and businesses, handhold assistance, variety of modes of transport and services under one platform, reliable and credible team who has expertise in providing international services for more than 15 years.</p>

                  <p>We partner with best and most reliable business players like FedEx, UPS, DHL etc.</p>

                  <p>Usually, customers go through various difficulties and have to take a lot of guidance to ensure their safe parcel delivery (especially international courier/cargo and customs clearance).Some of these difficulties include what can be shipped or what can’t, what risks are involved in customs clearance, what is the best mode, where one can get reasonable prices, not enough customer care support from the logistics company etc.</p>

                  <p>3's Deliveries has been created by taking these concerns in mind and what customers actually need. We have ensured customer-oriented processes from booking a parcel to delivery at the door.</p>

               </div>
            </div>
         </div>
      </div>
   </section>
   <!--about section end-->
  
   <?php echo $__env->make('section.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
</div>
<div id="myModal" class="modal weight-c">
   <div class="modal-content">
      <div class="modal-header">
         <h3>Your Quote from India to <span id="destination"></span></h3>
         <span class="close">&times;</span>
      </div>
      <table>
         <tr class="tr-header">
            <th>Services</th>
            <th>Weight</th>
            <th>Charges</th>
            <th>Book your order</th>
         </tr>

         <tr>
            <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
            <td id="ups"></td>
            <td id="appendata"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
            <td id="dhl"></td>
            <td id="dhlRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
            <td id="fdx"></td>
            <td id="fdxRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

      </table>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benfy/public_html/testing/deliveries/quickship/resources/views/pages/about.blade.php ENDPATH**/ ?>