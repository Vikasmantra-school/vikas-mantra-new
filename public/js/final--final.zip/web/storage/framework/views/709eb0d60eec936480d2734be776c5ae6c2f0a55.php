<?php echo e($r); ?>

<?php /**PATH /Users/rene/Desktop/wetransfer_deliveries-sql_2021-10-11_1457/benfy/quickship/resources/views/pages/test.blade.php ENDPATH**/ ?>