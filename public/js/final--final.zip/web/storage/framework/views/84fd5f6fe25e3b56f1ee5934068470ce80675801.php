<?php $__env->startSection('content'); ?>
<div class="main">
  <section class="pages-banner">
            <div class="section-lg section-header primary-bg" style="    padding-bottom: 83px;">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>FAQ's</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">FAQ's</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section section-sm">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-12">
                        <!--Accordion-->
                        <div class="accordion">
                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-1" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-1"><span class="h6 mb-0">How can I book my shipment with 3S Deliveries?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-1">
                                    <div class="accordion-content">
                                        <p>You can simply select the origin, destination, and required weight to get the best discounted rates instantly from top carriers like DHL, Fedex & UPS. After selecting the carrier suiting your preference, you can contact our customer support team Whatsapp/Call or E-mail to schedule the pickup of your shipment.</p>

                                    </div>
                                </div>
                            </div>
                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-2" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-2"><span class="h6 mb-0">Where all can my package be shipped?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-2">
                                    <div class="accordion-content">
                                        <p>With our services, you can deliver your shipment easily, safely to any country in the world without burning a big hole in your pocket. 3S Deliveries provide the cheapest, reliable, hassle free, door to door delivery services to majority of the countries around the world.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">What are the necessary documents needed to book the shipment?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>You need to provide a copy of your Aadhar card and Pan card (as per the sender’s current address for the pickup) along with your shipment.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">How can the payment be done for my shipment?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>All payments can be done easily by Cash, or Paytm or by Bank transfer.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">Will it be possible to get an invoice for my order?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>Yes. After packing and weighing, the shipment fee will be charged based on the final weight after packing. As soon as your shipment is picked & booked by our representative you will get an invoice having the weight of the shipment, fee charged for the shipment, items/goods description, tentative value of the items/goods quoted by the customer. The tentative value of your shipment must be less than INR 25000 for international delivery as per the industry guidelines.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">What is actual weight and volumetric or dimensional weight?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>
                                          <u>Actual weight</u> - Actual Weight is the definite product weight including packaging or the true weight of the package as per the weighing scale.
                                        </p>
                                        <p>
                                          <u>Dimensional or Volumetric Weight</u> - Dimensional weight, also known as volumetric weight, depends on the dimension or volume or size of the package. Dimensional or volumetric weight is a pricing technique for commercial freight transport, which uses an estimated weight that is calculated from the length, width, and height of the package. Dimensional or Volumetric weight is used when the space a shipment takes on an aircraft may cost more than the shipment's actual weight. Dimensional or volumetric weight defines how much space the package occupies according to its dimensions, which is then converted to its equivalent weight.
                                        </p>
                                        <p>
                                          The shipping fee is based upon the greater value, which may be the dimensional weight or the actual weight. 
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">Can I track my shipment throughout its delivery?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>Yes, after your shipment is picked up and generation of invoice, you will get the Tracking number within 24 hours. With the tracking number you can track your shipment in real time directly from our website.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">What does custom clearance delay mean in international shipment?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>All international shipments are required to go through a customs clearance procedure. During this process, a clearance delay may occur which might slow down the clearance process and delivery of your goods.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">What precaution should I take before sending a shipment?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>Avoid sending anything illegal or prohibited by law intentionally or unintentionally through3S Deliveries. The sender/customer will be solely responsible for any prohibited or restricted substance found/concealed in the shipment being sent through our services. The Customer is solely liable to pay penalties, face legal issues and other consequences for sending aforementioned items through our deliveries. Kindly go through the prohibited item list given on the website or check the latest list of prohibited items in sender’s or receiver’s country via the internet before booking a shipment.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">Do I need to go to the customs office?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>No. We provide hassle free, door to door delivery services around the world.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">What about Customs Duty Charges?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>Customs duty charges are separate from shipping charges and are not included in your shipping quote. Custom charges are determined by the Custom officer at the destination country and cannot be ascertained during the time of shipment. Customs duties may or may not be charged, and is determined by the destination country based on the type of shipment, value of shipment, and the content of shipment etc. So, custom fee being imposed on a shipment at the destination country, need to be paid by the recipient. Please contact our customer support team if you have additional queriers regarding custom duties.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">What if the package got damaged or delayed?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>We are partnered with top carriers like DHL, Fedex, UPS for shipment delivery. All items will be appropriately packed under your supervision for your utmost satisfaction. We are not responsible for any damage of goods or for delay in transit.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">Can we send Home Made food items?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>Yes, homemade food items including pickles, sweets, namkeen and snacks can be sent through our services. However, there are some restrictions in certain countries due to the COVID situation. Please contact our customer support team for the latest updates.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="card card-sm px-4 py-3 border border-light rounded mb-4">
                                <div data-target="#panel-3" class="accordion-panel-header icon-title collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="panel-3"><span class="h6 mb-0">How much it would cost me to send a package any country in the world?</span> <span class="icon"><i class="fas fa-angle-down"></i></span></div>
                                <div class="collapse" id="panel-3">
                                    <div class="accordion-content">
                                        <p>The rates vary according to the country, weight of shipment, fuel surcharge and promotional rates available at the time of shipment. Kindly check our website to get the best rates instantly using our freight calculator by selecting the origin, destination country and weight of the shipment. Please contact us for any additional queries regarding the cost information. </p>
                                    </div>
                                </div>
                            </div>




                            
                        </div>
                        <!--End of Accordion-->
                    </div>
                </div>
            </div>
        </section>
  
   
  
  
    <?php echo $__env->make('section.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
</div>
<div id="myModal" class="modal weight-c">
   <div class="modal-content">
      <div class="modal-header">
         <h3>Your Quote from India to <span id="destination"></span></h3>
         <span class="close">&times;</span>
      </div>
      <table>
         <tr class="tr-header">
            <th>Services</th>
            <th>Weight</th>
            <th>Charges</th>
            <th>Book your order</th>
         </tr>

         <tr>
            <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
            <td id="ups"></td>
            <td id="appendata"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
            <td id="dhl"></td>
            <td id="dhlRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
            <td id="fdx"></td>
            <td id="fdxRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

      </table>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benfy/public_html/testing/deliveries/web/resources/views/pages/faq.blade.php ENDPATH**/ ?>