<?php $__env->startSection('content'); ?>
<div class="main">
   <!--hero section start-->
   <section class="section weight-calc pt-9 pb-9 section-header" style="">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-md-7 col-lg-6">
               <div class="hero-slider-content">
                  <h1 class="display-2">Bridge Between You And Your Relations</h1>
                  <p class="">3's Deliveries connects critical components of the supply chain from a product’s manufacturing point to its point of consumption to ensure timely and efficient distribution of goods from producers to consumers. </p>

                  <form action="" class="tracking-form">
                     <input type="search" placeholder="Enter your tracking ID" class="tracking">
                     <button type="submit" class="btn">Submit</button>
                  </form>
                  

               </div>
            </div>
            <div class="col-md-5 col-lg-6 form-divv">
               <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                  <li class="nav-item" role="presentation">
                     <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Package</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Document</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Envelope</a>
                  </li>
               </ul>
               <div class="tab-content" id="pills-tabContent">
                  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                    <form id="form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="package" id="type">
                        <div class="container">
                           <div class="row">

                           <div class="col-12">
                              <div class="row">

                                    <div class="col-md-6 pl-0 select-div">
                                    <label for="from">Sending from</label>
                                       <select name="from">
                                             <option value="">India</option>
                                       </select>
                                    </div>

                                       <div class="col-md-6 pr-0 select-div">
                                       <label for="zone">Destination</label>
                                          <select id="zone" name="zone">
                                             <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($zone->zone_name); ?>#<?php echo e($zone->destination); ?>"><?php echo e($zone->destination); ?></option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                       </div>

                              </div>
                           </div>


                           <div class="col-12">
                              <div class="row row justify-content-center">

                                    <div class="col-md-9 pl-0 select-div">
                                       <label for="weight">Weights</label>
                                       <select id="weight" name="weight">
                                          <?php for($x = 0.5; $x <= 70; $x+=0.5): ?>
                                          <option value="<?php echo e($x); ?>"><?php echo e($x); ?></option>
                                          <?php endfor; ?>
                                       </select>
                                    </div>

                              </div>
                           </div>

                           <div class="col-12">
                              <div class="row form-btn">
                             
                                    <div class="col-md-12 pl-0">
                                       <button class="btn btn-secondary" type="submit" id="myBtn">Get Rates</button>
                                    </div>

                              </div>
                           </div>
                              
                           </div>
                        </div>
                     </form>
                  </div>

                  <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                  
                  </div>

                  <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                    
                  </div>

               </div>
            </div>
         </div>
      </div>
   </section>
   <!--hero section end-->

    <!--promo section start-->
   <section class="section section-sm pb-0 mt-n8 z-5 position-relative">
      <div class="container">
         <div class="row">
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-1 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-shipping-fast"></i></div>
                  <div class="promo-block-content">
                     <h5>Best Price</h5>
                     <p class="mb-0">We offer best discounted rates to the individual and commercial customers.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-2 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-globe"></i></div>
                  <div class="promo-block-content">
                     <h5>Tracking Visibility</h5>
                     <p class="mb-0">We provide instant tracking number for real time tracking and visibility of the shipment.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-3 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-user-clock"></i></div>
                  <div class="promo-block-content">
                     <h5>On Time Delivery</h5>
                     <p class="mb-0">We fulfill customer promises by delivering shipment on committed transit time.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
  


   <section class="section section-sm  third-section">
            <div class="container">
                <div class="row row-grid align-items-center">
                    <div class="col-12 col-lg-6">
                        <h2>Bringing you end to end supply chain solutions</h2>

                        <p>We at Global Dynamic Supply understand that customers have different needs. What works for some clients will not work for others. That’s why our sourcing services are flexible so that we can offer you the perfect mix of the global sourcing solutions that suit your individual needs most.</p>

                        <p>Customers may choose to carry out their supply through Global Dynamic Supply and take the most out of the process with our value pricing from fully vetted factories. Other customers, for example, might want to add on-site inspections, shipping &amp; logistics personalization, financing, and domestic warehousing services. At Global Dynamic Supply, you have the freedom to choose the service or mix of services that will ensure you get the most precise personal value.</p>

                    </div>
                    <div class="col-12 col-lg-6 ml-lg-auto">
                        <div class="row">
                            <div class="col-12 col-sm-6">
                                <div class="card bg-primary text-white shadow-soft rounded mb-4">
                                    <div class="px-3 px-lg-4 py-5 text-center">
                                        <span class="icon icon-lg d-block"><i class="fas fa-user-shield text-white"></i></span>
                                         <h5>Safe & Economical</h5>
                     <p class="mb-0 text-white">Save 50-60% on top branded carriers</p>
                                    </div>
                                </div>
                                <div class="card bg-secondary text-white shadow-soft rounded mb-4">
                                    <div class="px-3 px-lg-4 py-5 text-center">
                                        <span class="icon icon-lg d-block"><i class="fas fa-fire text-white"></i></span>
                                        <h5>220+</h5>
                     <p class="mb-0 text-white">Ship to countries all over the world</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 pt-lg-4">
                                <div class="card bg-secondary m-bg-primary text-white shadow-soft rounded mb-4">
                                    <div class="px-3 px-lg-4 py-5 text-center">
                                        <span class="icon icon-lg d-block"><i class="fas fa-lightbulb text-white"></i></span>
                                         <h5>3-6 Days</h5>
                     <p class="mb-0 text-white">Average delivery time worldwide</p>
                                    </div>
                                </div>
                                <div class="card bg-primary m-bg-secondary text-white shadow-soft rounded mb-4">
                                    <div class="px-3 px-lg-4 py-5 text-center">
                                        <span class="icon icon-lg d-block"><i class="fas fa-shapes text-white"></i></span>
                                        <h5>Real-Time Tracking</h5>
                     <p class="mb-0 text-white">Track your shipment in Real time</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

   <!--about section start-->
   <section class="section section-lg bg-grayed about-section">
      <div class="container">
         <div class="row justify-content-between align-items-center">
            <div class="col-md-12 col-lg-6 mb-4 mb-md-4 mb-lg-0">
               <div class="card bg-primary position-relative  shadow-lg fancy-radius p-3">
                  <div class="dot-shape-top position-absolute">
                     <img src="/img/common/color-shape.png" alt="dot" class="img-fluid">
                  </div>
                  <img class="fancy-radius img-fluid" src="/img/abt-us.png" alt="modern desk">
                  <div class="dot-shape position-absolute bottom-0">
                     <img src="/img/dot-shape.png" alt="dot">
                  </div>
               </div>
            </div>
            <div class="col-md-12 col-lg-5">
               <div class="video-promo-content">
                  <h2>About Us</h2>
                  <p>
                     Gifts and Homemade Items for loved ones, or Samples and Commercial orders for your businesses, or Unique Indian Items and Products etc. – Send it all with YourShipGlobal and we will deliver it with smiles.
                  </p>

                  <p>3's Deliveries provides an end to end, seamless and hassle-free international logistics services which includes Air Door to Door International Courier services, Freight Forwarding, Customs clearance, Sea freight LCL & FCL and First and Last mile deliveries of products/shipments.</p>

                  <a href="/about" class="btn btn-primary mt-3">Know More</a>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--about section end-->
  
   <!--services section start-->
   <section class="section services-section ptb-100">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-md-8">
               <div class="section-heading text-center mb-5">
                  <h2>Our Services</h2>
                  <p>You have a need, we have the solution</p>
               </div>
            </div>
         </div>
         <div class="row services-row">
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/FOOD & PERSONAL ITEMS.png">
                     <h3 class="h6">FOOD & PERSONAL ITEMS</h3>
                     <p>Homemade or Branded Food, Sweets and Personal items for personal use.</p>
                  </div>
               </div>
            </div>
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/AIR FREIGHT.png">
                     <h3 class="h6">AIR FREIGHT</h3>
                     <p>Door to Door international courier & cargo express services.</p>
                  </div>
               </div>
            </div>
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/CUSTOMS CLEARANCE.png">
                     <h3 class="h6">CUSTOMS CLEARANCE</h3>
                     <p>International customs clearance facility and customized services as per global compliance.</p>
                  </div>
               </div>
            </div>
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/SEA FREIGHT.png">
                     <h3 class="h6">SEA FREIGHT</h3>
                     <p>We provide freight forwarding and movement of goods through Sea mode in LCL & FCL.</p>
                  </div>
               </div>
            </div>
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/SPECIAL SERVICES.png">
                     <h3 class="h6">SPECIAL SERVICES</h3>
                     <p>International shipping of medicines, live pets and specific country based food items.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--services section end-->
  
   <?php echo $__env->make('section.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
   <!--cta section start-->
   <section class="section section-sm bg-dark-blue">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-12 col-lg-7 text-center">
               <div class="subscribe-content">
                  <span class="modal-icon icon icon-lg text-primary d-none d-md-block d-lg-block"><i class="fas fa-envelope-open-text"></i></span>
                  <h2 class="h4 modal-title my-2">Join our monthly news letter</h2>
                  <p class="mb-4">Get exclusive supply-chain and logistics news and updates from around the world.</p>
               </div>
               <div class="form-group">
                  <div class="d-sm-flex flex-column flex-sm-row mb-3 justify-content-center">
                     <input type="text" id="inputYourMail" placeholder="Enter your email address here" class="mr-sm-1 mb-2 mb-sm-0 form-control form-control-lg">
                     <button type="submit" class="ml-sm-1 btn btn-secondary">Subscribe</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--cta section end-->



</div>

<div id="myModal" class="modal weight-c">
   <div class="modal-content">
      <div class="modal-header">
         <h3>Your Quote from India to <span id="destination"></span></h3>
         <span class="close">&times;</span>
      </div>
      <table>
         <tr class="tr-header">
            <th>Services</th>
            <th>Weight</th>
            <th>Charges</th>
            <th>Book your order</th>
         </tr>

         <tr class="ups-div">
            <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
            <td id="ups"></td>
            <td id="appendata"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr class="dhl-div">
            <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
            <td id="dhl"></td>
            <td id="dhlRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr class="fdx-div">
            <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
            <td id="fdx"></td>
            <td id="fdxRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

      </table>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rene/Desktop/old/qs/resources/views/pages/home.blade.php ENDPATH**/ ?>