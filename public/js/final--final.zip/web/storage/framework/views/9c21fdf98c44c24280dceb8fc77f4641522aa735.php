    <?php $__env->startSection('content'); ?>

        <section class="pages-banner">
            <div class="section-lg section-header primary-bg" style="    padding-bottom: 83px;">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>Contact Us</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section section-lg">
            <div class="container contact">
                <div class="col-12 pb-3 message-box d-none">
                    <div class="alert alert-danger"></div>
                </div>
                <div class="row justify-content-around">
                    <div class="col-md-6">
                        <div class="contact-us-form bg-soft rounded p-5 contact-shadow">
                            <h4>Ready to get started?</h4>
                            <form action="/contact-us.php" method="POST" class="contact-us-form mt-4">
                                <div class="form-row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="name" placeholder="Enter name" required="required">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="email" class="form-control" name="email" placeholder="Enter email" required="required">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <textarea name="message" id="message" class="form-control" rows="7" cols="25" placeholder="Message"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 mt-3">
                                        <button type="submit" class="btn btn-secondary" id="btnContactUs" style="pointer-events: all; cursor: pointer;">
                                            Send Message
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-5 m-mt-20">
                        <div class="contact-us-content">
                            <h2>We partner with best business players.</h2>
                            <p>Under the leadership of experienced logistics professionals, the inception of 3's Deliveries has taken place. Leadership team has worked with blue chip companies like FedEx, UPS, Samsung & Amazon IN etc. and is carrying logistics experience of more than 20 years in International and domestic logistics in various areas ranging from International express, freight forwarding, manufacturing to E-commerce (retail) logistics business etc., 3's Deliveries has efficient team of expert professionals or SMEs who have designed the processes targeting customer needs and provide complete logistics solutions.</p>


                            <hr class="my-5">

                            <h5>Our Address</h5>
                            <address>
                                Lorem ipsum,<br>
                                dolor sit amet, consectetur adipiscing elit
                            </address>
                            <br>
                            <span>Phone: lorem</span> <br>
                            <span>Email: <a href="mailto:lorem@ipsum.com" class="link-color">lorem@ipsum.com</a></span>

                        </div>
                    </div>
                </div>
            </div>
        </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benfy/public_html/testing/deliveries/quickship/resources/views/pages/contact.blade.php ENDPATH**/ ?>