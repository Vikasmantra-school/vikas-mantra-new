<?php $__env->startSection('content'); ?>
<div class="main">
  <section class="pages-banner">
            <div class="section-lg section-header primary-bg" style="    padding-bottom: 83px;">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>Services</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Services</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
  
   <section class="section">

            <div class="container">

                <div class="row justify-content-between align-items-center">

                    <div class="col-md-12 col-lg-12 mb-4 mb-md-4 mb-lg-0">

                        <h2>Our Services</h2>

                        <p>We at 3's Deliveries are experts in connecting critical supply chain components from a product’s manufacturing point to its point of consumption. We guarantee timely and efficient distribution of goods from producers to consumers.</p>



                    </div>

                </div>

                <div class="row align-items-center mt-5 m-mt-0">

                    <div class="col-md-6">

                        <img src="/img/Food_and_Personal_Items.png">
                        
                    </div>

                    <div class="col-md-6 m-mt-20">

                        <h5>Food and personal belongings</h5>

                        <p class="mb-0">We offer international door-to-door shipment of homemade or branded food items in limited quantities such as sweets, namkeen, pickles, powder spices, etc. We also ship personal belongings such as clothing, shoes, and stationery.</p>

                        <a href="/contact-us" class="btn btn-primary mt-3">Know More</a>
                        

                    </div>

                </div>

                <div class="row align-items-center mt-6">

                    <div class="col-md-6 div-sec m-mt-20">

                        <h5>Air Freight</h5>

                        <p>We are partners with top business players such as FEDEX, DHL, UPS, etc., to provide secure, reliable, and hassle-free international courier and cargo services. Some of these services include Door to Door, Airport to Door, & Airport to Airport for personal and commercial purposes.</p>

                        <a href="/contact-us" class="btn btn-primary mt-3">Know More</a>

                    </div>


                    <div class="col-md-6 div-first">

                        <img src="/img/Air_Freight.png">
                        
                    </div>

                </div>

                <div class="row align-items-center mt-6">

                    <div class="col-md-6">

                        <img src="/img/Customs_Clearance.png">
                        
                    </div>

                    <div class="col-md-6 m-mt-20">

                        <h5>Customs Clearance</h5>

                        <p class="mb-0">Under the ambit of global compliance statutory regulations, we provide international customs clearance for Import and Export with tailor-made solutions for business, commercial, and individual clients.</p>

                        <a href="/contact-us" class="btn btn-primary mt-3">Know More</a>
                        

                    </div>

                </div>

               <!--  -->
                  <div class="row align-items-center mt-6">

                     <div class="col-md-6 div-sec m-mt-20">
                        <h5>Sea Freight</h5>
                        <p>We offer freight forwarding and movement of goods through sea mode in both LCL (Less Container Load) and FCL (Full Container Load) forms with renowned and trustworthy shipping liners.</p>

                        <a href="/contact-us" class="btn btn-primary mt-3">Know More</a>
                     </div>


                    <div class="col-md-6 div-first">
                        <img src="/img/Sea_Freight.png">
                    </div>

                  </div>
               <!--  -->

               <div class="row align-items-center mt-6">

                    <div class="col-md-6">

                        <img src="/img/Special_Services.png">
                        
                    </div>

                    <div class="col-md-6 m-mt-20">

                        <h5>Special Services</h5>

                        <p class="mb-0">We provide special services such as international shipment of certain medicines such as Allopathy, Homeopathy, Ayurveda, etc. We also specialize in the international relocation of live pets. We also have expertise in importing country-specific and native culinary items such as Korean and Japanese cuisine.</p>

                        <a href="/contact-us" class="btn btn-primary mt-3">Know More</a>
                        

                    </div>

                </div>


<!--  -->

            </div>

        </section>
  
  
    <?php echo $__env->make('section.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
</div>
<div id="myModal" class="modal weight-c">
   <div class="modal-content">
      <div class="modal-header">
         <h3>Your Quote from India to <span id="destination"></span></h3>
         <span class="close">&times;</span>
      </div>
      <table>
         <tr class="tr-header">
            <th>Services</th>
            <th>Weight</th>
            <th>Charges</th>
            <th>Book your order</th>
         </tr>

         <tr>
            <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
            <td id="ups"></td>
            <td id="appendata"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
            <td id="dhl"></td>
            <td id="dhlRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
            <td id="fdx"></td>
            <td id="fdxRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

      </table>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benfy/public_html/testing/deliveries/web/resources/views/pages/services.blade.php ENDPATH**/ ?>