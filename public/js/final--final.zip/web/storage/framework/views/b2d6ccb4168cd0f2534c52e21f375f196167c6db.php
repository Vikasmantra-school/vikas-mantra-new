<!--footer section start-->

<footer class="footer-wrap">

<div class="footer footer-top section section-sm">

    <div class="container">

        <div class="row">

            <div class="col-sm-6 col-lg-5">

                <a class="footer-brand mr-lg-5 d-flex" href="/">

                    <img src="/img/logo/logo.png" class="mr-3" alt="Footer logo">

                </a>

                <p class="my-4">At 3's Deliveries, we aim to provide our customers with the exact products they need, custom-built to their specifications.</p>

            </div>

            <div class="col-sm-6 col-lg-2 mb-lg-0">

                <h5 class="mb-4">Quick Links</h5>

                <ul class="links-vertical">

                    <li><a target="_blank" href="/">Home</a></li>

                    <li><a target="_blank" href="/about.php">About Us</a></li>

                    <li><a target="_blank" href="/services.php">Careers</a></li>

                </ul>

            </div>

            <div class="col-sm-6 col-lg-2 mb-lg-0">

                <ul class="links-vertical mt-5">

                    <li><a target="_blank" href="/our-networks.php">Our Networks</a></li>

                    <li><a target="_blank" href="/faq.php">Faq</a></li>

                    <li><a target="_blank" href="/contact-us.php">Contact Us</a></li>

                </ul>

            </div>

            <div class="col-sm-6 col-lg-3">

                <h5 class="mb-4">Social Media</h5>

                <div class="btn-wrapper mt-4">

                    <button class="btn btn-icon-only btn-pill btn-twitter mr-2 icon icon-xs icon-shape" type="button" data-toggle="tooltip" data-placement="top" title="" data-original-title="40k Followers">

                        <span aria-hidden="true" class="fab fa-twitter"></span>

                    </button>

                    <button class="btn btn-icon-only btn-pill btn-facebook mr-2 icon icon-xs icon-shape" type="button" data-toggle="tooltip" data-placement="top" title="" data-original-title="50k Like">

                        <span aria-hidden="true" class="fab fa-facebook-f"></span>

                    </button>

                    <button class="btn btn-icon-only btn-pill btn-instagram mr-2 icon icon-xs icon-shape" type="button" data-toggle="tooltip" data-placement="top" title="" data-original-title="25k Followers">

                        <span aria-hidden="true" class="fab fa-instagram"></span>

                    </button>

                </div>

            </div>

<!-- 
            <div class="float-btn">

                <a href="/contact-us.php" class="btn btn-secondary mt-4 d-none">Contact Us</a>


            </div>
 -->
        
        </div>

    </div>

</div>

<div class="footer py-3 bg-soft text-white border-top border-variant-default">

    <div class="container">

        <div class="row">

            <div class="col">

                <div class="d-flex text-center justify-content-center align-items-center">

                    <p class="copyright pb-0 mb-0">Copyrights © 2021. All

                        rights reserved.
                    </p>

                </div>

            </div>

        </div>

    </div>

</div>

</footer>

<!--footer section end--><?php /**PATH /Users/rene/Desktop/qs/resources/views/layouts/footer.blade.php ENDPATH**/ ?>