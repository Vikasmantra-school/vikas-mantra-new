  <!--scroll bottom to top button start-->

  <button class="scroll-top scroll-to-target" data-target="html">

<span class="fas fa-hand-point-up"></span>

</button>

<!--scroll bottom to top button end-->

<!--build:js-->

<script src="/js/vendors/jquery-3.5.1.min.js"></script>

<script src="/js/vendors/popper.min.js"></script>

<script src="/js/vendors/bootstrap.min.js"></script>

<script src="/js/vendors/jquery.magnific-popup.min.js"></script>

<script src="/js/vendors/jquery.easing.min.js"></script>

<script src="/js/vendors/mixitup.min.js"></script>

<script src="/js/vendors/headroom.min.js"></script>

<script src="/js/vendors/smooth-scroll.min.js"></script>

<script src="/js/vendors/wow.min.js"></script>

<script src="/js/vendors/owl.carousel.min.js"></script>

<script src="/js/vendors/jquery.waypoints.min.js"></script>

<!--<script src="/js/vendors/countUp.min.js"></script>-->

<script src="/js/vendors/jquery.countdown.min.js"></script>

<script src="/js/vendors/validator.min.js"></script>

<script src="/js/app.js"></script>

<!--endbuild-->

<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
  $('#feedback').remove();
  $('#dhlRateId').remove();
  $('#fdxRateId').remove();
  $('#country').remove();
  $('#upsId').remove();
  $('#dhlId').remove();
  $('#fdxId').remove();
  $('#typeHide').remove();

  $(".ups-div").show();
    $(".dhl-div").show();
    $(".fdx-div").show();
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
    $('#feedback').remove();
    $('#dhlRateId').remove();
    $('#fdxRateId').remove();
    $('#country').remove();
    $('#upsId').remove();
    $('#dhlId').remove();
    $('#fdxId').remove();
    $('#typeHide').remove();

    $(".ups-div").show();
    $(".dhl-div").show();
    $(".fdx-div").show();
  }
}
</script>

<script type="text/javascript">
$(window).scroll(function() {    
  var scroll = $(window).scrollTop();

  if (scroll >= 500) {
      $(".float-btn .btn").removeClass("d-none");
  }
  else{
      $(".float-btn .btn").addClass("d-none");
  }

});
</script>

<script type="text/javascript">

  $(function() {
    $('#form').submit(function(e){
      var route = $('#form').data('route');

      var formData = {
        z: $("#zone").val().split("#")[0],
        w: $("#weight").val(),
        x: $("#zone").val().split("#")[1],
        t: $("#type").val()
      };

      $.ajax({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type: 'POST',
        url: "/rates/" + formData.z +'/' + formData.w +'/' + formData.t,
        data: formData,
        success: function(Response){

          if(Response[0] == '-'){
            $(".ups-div").hide();
            $("#dhlRate").append('<div id="dhlRateId">INR '+Response[1]+'</div>');
            $("#fdxRate").append('<div id="fdxRateId">INR '+Response[2]+'</div>');

          }
          else if(Response[0] == '-',Response[1] == '-'){
            $(".ups-div").hide();
            $(".dhl-div").hide();
            $("#fdxRate").append('<div id="fdxRateId">INR '+Response[2]+'</div>');
          }
          else if(Response[0] == '-',Response[2] == '-'){
            $(".ups-div").hide();
            $("#dhlRate").append('<div id="dhlRateId">INR '+Response[1]+'</div>');
            $(".fdx-div").hide();
          }
          //

          else if(Response[1] == '-'){
            $("#appendata").append('<div id="feedback">INR '+Response[0]+'</div>');
            $(".dhl-div").hide();
            $("#fdxRate").append('<div id="fdxRateId">INR '+Response[2]+'</div>');
          }
          else if(Response[1] == '-',Response[0] == '-'){
            $(".ups-div").hide();
            $(".dhl-div").hide();
            $("#fdxRate").append('<div id="fdxRateId">INR '+Response[2]+'</div>');
          }
          else if(Response[1] == '-',Response[2] == '-'){
            $("#appendata").append('<div id="feedback">INR '+Response[0]+'</div>');
            $(".dhl-div").hide();
            $(".fdx-div").hide();
          }

          else if(Response[2] == '-'){
            $("#appendata").append('<div id="feedback">INR '+Response[0]+'</div>');
            $("#dhlRate").append('<div id="dhlRateId">INR '+Response[1]+'</div>');
            $(".fdx-div").hide();
          }

          else{

            $("#appendata").append('<div id="feedback">INR '+Response[0]+'</div>');
            $("#dhlRate").append('<div id="dhlRateId">INR '+Response[1]+'</div>');
            $("#fdxRate").append('<div id="fdxRateId">INR '+Response[2]+'</div>');

          }

          $("#destination").append('<span id="country">'+formData.x+'</span>');

          $("#typeShow").append('<span id="typeHide">'+formData.t+'</span>');

          $("#ups").append('<span id="upsId">Upto '+formData.w+' Kg</span>');
          $("#dhl").append('<span id="dhlId">Upto '+formData.w+' Kg</span>');
          $("#fdx").append('<span id="fdxId">Upto '+formData.w+' Kg</span>');

          console.log(Response);

        }
      });

      e.preventDefault();
    });
  });

</script>

<script>
  $(window).scroll(function() {    
    var scroll = $(window).scrollTop();

     //>=, not <=
    if (scroll >= 1) {
        //clearHeader, not clearheader - caps H
        $(".navbar").addClass("affix");
    }

    else{
      $(".navbar").removeClass("affix");
    }
}); //missing );
</script>
<?php /**PATH /Users/rene/Desktop/old/qs/resources/views/layouts/script.blade.php ENDPATH**/ ?>