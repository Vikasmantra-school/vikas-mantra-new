<?php $__env->startSection('content'); ?>
<div class="main">
   <!--hero section start-->
   <section class="section weight-calc pt-9 pb-9 section-header" style="">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-md-7 col-lg-6">
               <div class="hero-slider-content">
                  <h1 class="display-2">Bridge Between You And Your Relations</h1>
                  <p class="">3's Deliveries connects critical components of the supply chain from a product’s manufacturing point to its point of consumption to ensure timely and efficient distribution of goods from producers to consumers. </p>

                  <form action="" class="tracking-form">
                     <input type="search" placeholder="Enter your tracking ID" class="tracking">
                     <button type="submit" class="btn">Submit</button>
                  </form>
                  

               </div>
            </div>
            <div class="col-md-5 col-lg-6 form-divv">
               <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                  <li class="nav-item" role="presentation">
                     <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">UPS</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">DHL</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">FEDEX</a>
                  </li>
               </ul>
               <div class="tab-content" id="pills-tabContent">
                  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">

                    <?php if(count($errors) > 0): ?>

                        <ul>    
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    <?php endif; ?>

                    <?php if($message = Session::get('success')): ?>
                        <?php echo e($message); ?>

                    <?php endif; ?>

                    <?php if(session('success')): ?>
                        <strong><?php echo e(session('success')); ?></strong>
                    <?php endif; ?>
                     <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/upload/file')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="package" id="type">
                        <div class="container">
                            <div class="row">

                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Select File</label>
                                            <input type="file" name="select_file"/>
                                        </div>

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Upload</label>
                                            <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                                Upload
                                            </button>
                                        </div>

                                    </div>
                                </div>

                                <p>
                                    <a href="<?php echo e(url('export')); ?>">Export Users</a>
                                </p>

                            </div>
                        </div>
                     </form>
                  </div>

                  <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                  <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/upload/file/dhl')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="container">
                            <div class="row">

                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Select File</label>
                                            <input type="file" name="select_file"/>
                                        </div>

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Upload</label>
                                            <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                                Upload
                                            </button>
                                        </div>

                                    </div>
                                </div>

                                <p>
                                    <a href="<?php echo e(url('export')); ?>">Export Users</a>
                                </p>

                            </div>
                        </div>
                     </form>

                  </div>

                  <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                  <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/upload/file/fdx')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="container">
                            <div class="row">

                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Select File</label>
                                            <input type="file" name="select_file"/>
                                        </div>

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Upload</label>
                                            <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                                Upload
                                            </button>
                                        </div>

                                    </div>
                                </div>

                                <p>
                                    <a href="<?php echo e(url('export')); ?>">Export Users</a>
                                </p>

                            </div>
                        </div>
                     </form>
                  </div>

               </div>
            </div>
         </div>
      </div>
   </section>
   <!--hero section end-->

   
   <!--cta section start-->
   <section class="section section-sm bg-dark-blue">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-12 col-lg-7 text-center">
               <div class="subscribe-content">
                  <span class="modal-icon icon icon-lg text-primary d-none d-md-block d-lg-block"><i class="fas fa-envelope-open-text"></i></span>
                  <h2 class="h4 modal-title my-2">Join our monthly news letter</h2>
                  <p class="mb-4">Get exclusive supply-chain and logistics news and updates from around the world.</p>
               </div>
               <div class="form-group">
                  <div class="d-sm-flex flex-column flex-sm-row mb-3 justify-content-center">
                     <input type="text" id="inputYourMail" placeholder="Enter your email address here" class="mr-sm-1 mb-2 mb-sm-0 form-control form-control-lg">
                     <button type="submit" class="ml-sm-1 btn btn-secondary">Subscribe</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--cta section end-->



</div>
<div id="myModal" class="modal weight-c">
   <div class="modal-content">
      <div class="modal-header">
         <h3>Your Quote from India to <span id="destination"></span></h3>
         <span class="close">&times;</span>
      </div>
      <table>
         <tr class="tr-header">
            <th>Services</th>
            <th>Weight</th>
            <th>Charges</th>
            <th>Book your order</th>
         </tr>

         <tr>
            <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
            <td id="ups"></td>
            <td id="appendata"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
            <td id="dhl"></td>
            <td id="dhlRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
            <td id="fdx"></td>
            <td id="fdxRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

      </table>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rene/Desktop/qs/resources/views/pages/upload.blade.php ENDPATH**/ ?>