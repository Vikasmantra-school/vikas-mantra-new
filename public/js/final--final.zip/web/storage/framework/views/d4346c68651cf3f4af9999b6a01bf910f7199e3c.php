

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <!--favicon icon-->
      <link rel="icon" href="/img/favicon.png" type="image/png" sizes="16x16">
      <!--title-->
      <title>3S Deliveries</title>
      <!--build:css-->
      <link rel="stylesheet" href="/css/main.css">
      <link rel="stylesheet" href="/css/style.css">
      <!-- endbuild -->
   </head>
   <body>

      <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="main">

        <?php echo $__env->yieldContent('content'); ?>
         
      </div>

      <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body" >


            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary">Save changes</button>
            </div>
          </div>
        </div>
      </div>

      <!--  -->

      <!-- <a href="tel:+919500077678" class="fixed-app callBtn"><i class="fa fa-phone"></i> +91 – 95000 77678</a> -->
     

   </body>
</html><?php /**PATH /home/benfy/public_html/testing/deliveries/quickship/resources/views/layouts/app.blade.php ENDPATH**/ ?>