<?php $__env->startSection('content'); ?>
<div class="main">
   <!--hero section start-->
   <section class="section weight-calc pt-9 pb-9 section-header text-white gradient-overly-right-color" style="background: url('/img/banner/home-banner2.jpg')no-repeat center center / cover">
      <div class="container">
         <div class="row">
            <div class="col-md-7 col-lg-6">
               <div class="hero-slider-content">
                  <h1 class="display-2">A reliable sourcing partner for all your needs!</h1>
                  <p class="text-white">Global logistics connects critical components of the supply chain from a product’s manufacturing point to its point of consumption to ensure timely and efficient distribution of goods from producers to consumers. </p>
                  <a href="/services.php" class="btn btn-secondary mt-4 services-btn">Our Services</a>
               </div>
            </div>
            <div class="col-md-5 col-lg-6">
               <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                  <li class="nav-item" role="presentation">
                     <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Individual</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Commercial</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Customs Clearance</a>
                  </li>
               </ul>
               <div class="tab-content" id="pills-tabContent">
                  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                     <form id="form">
                        <?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
                        <div class="container">
                           <div class="row">

                                <!-- <div class="col-md-6 pl-0 select-div">

                                    <div class="row">

                                    <div class="col-md-6 pl-0"><label for="from">Sending From...</label></div>

                                        <div class="col-md-6">
                                            <select name="from">
                                                <option value="">India</option>
                                            </select>
                                        </div>
                                        

                                    </div>

                                </div> -->

                            <div class="col-md-6 pl-0 select-div">
                                <select name="from">
                                    <option value="">India</option>
                                </select>
                            </div>

                              <div class="col-md-6 pr-0 select-div">
                                 <select id="zone" name="zone">
                                    <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($zone->zone_name); ?>#<?php echo e($zone->destination); ?>"><?php echo e($zone->destination); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                              </div>
                              <div class="col-md-6 pl-0 select-div">
                                 <select id="weight" name="weight">
                                    <?php $__currentLoopData = $weights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($weight->weight); ?>"><?php echo e($weight->weight); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                              </div>
                              <div class="col-md-6 pr-0">
                                 <button class="btn btn-secondary" type="submit" id="myBtn">Get Rates</button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
                  <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">...</div>
                  <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">...</div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--hero section end-->
   <!--promo section start-->
   <section class="section section-sm pb-0 mt-n8 z-5 position-relative">
      <div class="container">
         <div class="row">
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-1 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-shipping-fast"></i></div>
                  <div class="promo-block-content">
                     <h5>Shipping and Logistic Services</h5>
                     <p class="mb-0">Our knowledge and experienced logistics teams can work to ensure that your products are delivered when and where you need them. </p>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-2 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-globe"></i></div>
                  <div class="promo-block-content">
                     <h5>Global Expansion Consulting</h5>
                     <p class="mb-0">No matter how large or small your company, our personalized global expansion consulting services can meet your needs.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-3 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-user-clock"></i></div>
                  <div class="promo-block-content">
                     <h5>End to end supply chain</h5>
                     <p class="mb-0">Efficient Supply Chain Management not only ensures timely delivery of goods to keep customers satisfied but also brings down costs for the manufacturer by reducing wastage.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--promo section end-->
   <!--about section start-->
   <section class="section section-lg">
      <div class="container">
         <div class="row justify-content-between align-items-center">
            <div class="col-md-12 col-lg-6 mb-4 mb-md-4 mb-lg-0">
               <div class="card bg-primary position-relative  shadow-lg fancy-radius p-3">
                  <div class="dot-shape-top position-absolute">
                     <img src="/img/common/color-shape.png" alt="dot" class="img-fluid">
                  </div>
                  <img class="fancy-radius img-fluid" src="/img/common/product-sourcing.jpg" alt="modern desk">
                  <div class="dot-shape position-absolute bottom-0">
                     <img src="/img/dot-shape.png" alt="dot">
                  </div>
               </div>
            </div>
            <div class="col-md-12 col-lg-5">
               <div class="video-promo-content">
                  <h2>Product Sourcing</h2>
                  <ul class="list-unstyled tech-feature-list">
                     <p>At Global Dynamic Supply, we aim to provide our customers with the exact products they need, custom-built to their specifications. As a global sourcing company, we’re able to provide quality global product sourcing services that ensure your finished products are made in the best way possible.</p>
                     <p>A focal point of our business is maintaining quality. Whether you require products manufactured in China, India or any other country, our team is more than capable of fulfilling your custom product needs. Our global component sourcing services are guaranteed to serve you well, and we look forward to assisting you.</p>
                  </ul>
                  <a href="/contact-us.php" class="btn btn-primary  mt-3">Contact Us</a>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--about section end-->
   <!--cta section start-->
   <section class="py-0 text-white" style="background: url('/img/banner/counting-banner2.jpg')no-repeat center center fixed">
      <div class="section py-4 bg-gradient-primary">
         <div class="container">
            <div class="row">
               <div class="col-6 col-md-6 col-lg-3 mb-4 mb-md-4 mb-lg-0">
                  <div class="icon-box text-center">
                     <div class="icon icon-md"><i class="fas fa-user"></i></div>
                     <span class="counter d-block display-3 my-2" data-count="2543">0</span>
                     <h3 class="h6">Factories Evaluated</h3>
                  </div>
               </div>
               <div class="col-6 col-md-6 col-lg-3 mb-4 mb-md-4 mb-lg-0">
                  <div class="icon-box text-center">
                     <div class="icon icon-md"><i class="fas fa-eye"></i></div>
                     <span class="counter d-block display-3 my-2" data-count="54">0</span>
                     <h3 class="h6">Sourcing Agents</h3>
                  </div>
               </div>
               <div class="col-6 col-md-6 col-lg-3 mb-4 mb-md-4 mb-lg-0">
                  <div class="icon-box text-center">
                     <div class="icon icon-md"><i class="fas fa-trophy"></i></div>
                     <span class="counter d-block display-3 my-2" data-count="100">0</span>
                     <h3 class="h6">Products Sourced</h3>
                  </div>
               </div>
               <div class="col-6 col-md-6 col-lg-3 mb-4 mb-md-4 mb-lg-0">
                  <div class="icon-box text-center">
                     <div class="icon icon-md"><i class="fas fa-medal"></i></div>
                     <span class="counter d-block display-3 my-2" data-count="40">0</span>
                     <h3 class="h6">Active Customers</h3>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--cta section end-->
   <!--services section start-->
   <section class="section services-section ptb-100">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-md-8">
               <div class="section-heading text-center mb-5">
                  <h2>Our Process</h2>
                  <p>Our qualified and experienced logistics teams can work to ensure that your products are delivered when and where you need them</p>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 mb-4 mb-md-4">
               <div class="services-single d-flex p-5 shadow-sm rounded bg-dark-grey">
                  <div class="services-content-wrap">
                     <h2 class="h2 text-center">01</h2>
                     <h3 class="h6 text-center">Research & Supplier Analysis</h3>
                     <p>We make a list of the supplier and issue signed offers for every product. We will do that together with you and take care of all documentation.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 mb-4 mb-md-4">
               <div class="services-single d-flex p-5 shadow-sm bg-white rounded">
                  <div class="services-content-wrap">
                     <h2 class="h2 text-center">02</h2>
                     <h3 class="h6 text-center">Official Contract</h3>
                     <p>After we have an official offer and confirmation of supplier we continue with the important discussion of Commercial Terms.. RFP/RFQ, price terms, and negotiations are the main topics we will talk about with you.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 mb-4 mb-md-4">
               <div class="services-single d-flex p-5 shadow-sm bg-white rounded">
                  <div class="services-content-wrap">
                     <h2 class="h2 text-center">03</h2>
                     <h3 class="h6 text-center">Sample Product Testing</h3>
                     <p>We will request samples from the supplier and we will send them to you for a review of the product. If you don’t like it, we can discuss a supplier change.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 mb-4 mb-md-4">
               <div class="services-single d-flex p-5 shadow-sm bg-dark-grey rounded">
                  <div class="services-content-wrap">
                     <h2 class="h2 text-center">04</h2>
                     <h3 class="h6 text-center">Quality Control</h3>
                     <p>We will do a pre-shipping inspection, ISIR Process Flow Chart, Process FMEA, Control Plan, CPK analysis, and any other testing you would want.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 mb-4 mb-md-4">
               <div class="services-single d-flex p-5 shadow-sm bg-dark-grey rounded">
                  <div class="services-content-wrap">
                     <h2 class="h2 text-center">05</h2>
                     <h3 class="h6 text-center">Logistics</h3>
                     <p>We have another team of suppliers who will transport your product on Air, Sea, Train, or land and will handle border control so you get your products on time.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--services section end-->
   <!--customer logo section start-->
   <div class="section section-sm pt-0">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-lg-8">
               <div class="text-center">
                  <h3>Trusted by leading brands worldwide</h3>
               </div>
            </div>
            <!--customer logo section start-->
            <div class="col-auto pt-4">
               <ul class="list-unstyled d-flex flex-wrap brand-logos mb-0">
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo1.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo2.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo3.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo4.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-5">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo5.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo6.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo7.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo8.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo9.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo10.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo11.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo12.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/logo13.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/amazon.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/bombardier.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/canadian-tire.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/loblaws.png" alt="client logo">
                     </div>
                  </li>
                  <li class="my-3 mx-3 mx-lg-4">
                     <div class="customer-logo">
                        <img src="/img/client-logos/pepsi.png" alt="client logo">
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </div>
   <!--customer logo section end-->
   <!--team section start-->
   <section class="section section-sm pt-0">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-lg-8">
               <div class="section-heading text-center mb-5">
                  <h3>Testimonials</h3>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-12 col-md-6 col-lg-3 mb-md-4 mb-lg-0 mb-4">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Edward Zhang</h3>
                        <p class="card-text pt-4">The GDS team were thoroughly professional in their approach, offered prompt assistance and offered multiple options. Highly knowledgeable supply chain specialists!</p>
                        <p class="text-default small mt-5 mb-0"><b>Canadian Tire</b></p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 mb-md-4 mb-lg-0 mb-4">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Michael Johnson</h3>
                        <p class="card-text pt-4">As we are an essential business, our operations had to continue. When the whole world was at a shortage for safety supplies, GDS fulfilled our order and delivered on time.</p>
                        <p class="text-default small mt-5 mb-0"><b>Pepsi</b></p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 mb-md-4 mb-lg-0 mb-4">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Laura Kingsley</h3>
                        <p class="card-text pt-4">Team GDS is well connected and organized. We weren’t sure what we wanted, GDS guided us throughout the entire process and ensured we found the right fit, highly recommended.</p>
                        <p class="text-default small mt-5 mb-0"><b>Cineplex</b></p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 mb-md-4 mb-lg-0 mb-4">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Victor Mendez</h3>
                        <p class="card-text pt-4">Transparent and easy to communicate. Every business needs things fast. The specialists at GDS were clear about the deadlines and provided us excellent support over the entire process.</p>
                        <p class="text-default small mt-5 mb-0"><b>Bombardier</b></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--team section end-->
   <!--cta section start-->
   <section class="section section-sm bg-dark-blue">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-12 col-lg-7 text-center">
               <div class="subscribe-content">
                  <span class="modal-icon icon icon-lg text-primary d-none d-md-block d-lg-block text-white"><i class="fas fa-envelope-open-text text-white"></i></span>
                  <h2 class="h4 modal-title my-2 text-white">Join our monthly news letter</h2>
                  <p class="mb-4 text-white">Get exclusive supply-chain and logistics news and updates from around the world.</p>
               </div>
               <div class="form-group">
                  <div class="d-sm-flex flex-column flex-sm-row mb-3 justify-content-center">
                     <input type="text" id="inputYourMail" placeholder="Enter your email address here" class="mr-sm-1 mb-2 mb-sm-0 form-control form-control-lg">
                     <button type="submit" class="ml-sm-1 btn btn-secondary">Subscribe</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--cta section end-->
</div>
<div id="myModal" class="modal weight-c">
   <div class="modal-content">
      <span class="close">&times;</span>
      <div class="modal-header">
         <h3>Your Quote from India to <span id="destination"></span></h3>
      </div>
      <table>
         <tr class="tr-header">
            <th>Services</th>
            <th>Weight</th>
            <th>Charges</th>
         </tr>
         <tr>
            <td><img class="courier" src="https://www.yourshipglobal.in/images/home-logo-3.jpg" alt=""></td>
            <td id="wid"></td>
            <td id="appendata"></td>
         </tr>
      </table>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rene/Desktop/wetransfer_deliveries-sql_2021-10-11_1457/benfy/quickship/resources/views/pages/home.blade.php ENDPATH**/ ?>