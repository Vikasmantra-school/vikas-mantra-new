<?php $__env->startSection('content'); ?>
<div class="main">
   <!--hero section start-->
   <section class="section weight-calc pt-9 pb-9 section-header" style="">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-md-7 col-lg-6">
               <div class="hero-slider-content">
                  <h1 class="display-2">Bridging The Gap Between You And Your Loved Ones</h1>
                  <p class="">3's Deliveries is a freight forwarding company offering a variety of services including the curation of a supply chain system from the manufacturing point of the product to its final destination, ensuring on-time and quality delivery from producers to consumers. </p>

                  <form action="" class="tracking-form">
                     <input type="search" placeholder="Enter your tracking ID" class="tracking">
                     <button type="submit" class="btn">Submit</button>
                  </form>
                  

               </div>
            </div>
            <div class="col-md-5 col-lg-6 form-divv">

              <h3>Get Your Quotation Now</h3>

               <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">

                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-<?php echo e($type->name); ?>-tab" data-toggle="pill" href="#pills-<?php echo e($type->name); ?>" role="tab" aria-controls="pills-<?php echo e($type->name); ?>" aria-selected="true"><?php echo e($type->name); ?></a>
                  </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </ul>

               <div class="tab-content" id="pills-tabContent">

                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <div class="tab-pane fade" id="pills-<?php echo e($type->name); ?>" role="tabpanel" aria-labelledby="pills-<?php echo e($type->name); ?>-tab">

                    <form id="form-<?php echo e($type->name); ?>">

                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="<?php echo e($type->name); ?>" id="type-<?php echo e($type->name); ?>">
                        <div class="container">
                           <div class="row">

                           <div class="col-12">
                              <div class="row">

                                    <div class="col-md-6 pl-0 select-div">
                                    <label for="from">Sending from</label>
                                       <select name="from">
                                             <option value="">India</option>
                                       </select>
                                    </div>

                                       <div class="col-md-6 pr-0 select-div">
                                       <label for="zone">Destination</label>
                                          <select id="zone-<?php echo e($type->name); ?>" name="zone">
                                             <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($zone->zone_name); ?>#<?php echo e($zone->destination); ?>"><?php echo e($zone->destination); ?></option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                       </div>

                              </div>
                           </div>


                           <div class="col-12">
                              <div class="row row justify-content-center">

                                    <div class="col-md-9 pl-0 select-div">
                                       <label for="weight">Weights</label>
                                       <select id="weight-<?php echo e($type->name); ?>" name="weight">

                                        <?php if(($type->max) == 'envelope'): ?>

                                          <option value="envelope">envelope</option>

                                        <?php else: ?>

                                          <?php for($x = 0.5; $x <= $type->max; $x+=0.5): ?>
                                            <option value="<?php echo e($x); ?>"><?php echo e($x); ?></option>
                                          <?php endfor; ?>

                                        <?php endif; ?>

                                       </select>
                                    </div>

                              </div>
                           </div>

                           <div class="col-12">
                              <div class="row form-btn">
                             
                                    <div class="col-md-12 pl-0">
                                       <button class="btn btn-secondary" type="submit" id="myBtn-<?php echo e($type->name); ?>">Get Rates</button>
                                    </div>

                              </div>
                           </div>
                              
                           </div>
                        </div>
                     </form>
                  </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


               </div>
            </div>
         </div>
      </div>
   </section>
   <!--hero section end-->

    <!--promo section start-->
   <section class="section section-sm pb-0 mt-n8 z-5 position-relative">
      <div class="container">
         <div class="row">
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-1 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-shipping-fast"></i></div>
                  <div class="promo-block-content">
                     <h5>Affordable Prices</h5>
                     <p class="mb-0">We offer services at affordable prices to individuals and commercial clients.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-2 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-globe"></i></div>
                  <div class="promo-block-content">
                     <h5>Tracking Visibility</h5>
                     <p class="mb-0">Providing instant tracking details for real-time tracking of the shipment.</p>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-lg-4 mb-md-4 mb-4 mb-lg-0">
               <div class="single-promo-block promo-hover-bg-3 hover-image shadow p-5 rounded-custom bg-white">
                  <div class="icon icon-lg text-primary"><i class="fas fa-user-clock"></i></div>
                  <div class="promo-block-content">
                     <h5>On-time Delivery</h5>
                     <p class="mb-0">Committed to fulfilling the customer's promises by delivering on time. </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
  


   <section class="section section-sm third-section">
            <div class="container">
                <div class="row row-grid align-items-center">
                    <div class="col-12 col-lg-6">
                        <h2>Bringing you closer to the people you care about</h2>

                        <p>We at 3's Deliveries believe that each customer is unique and so are their needs. Our services are designed flexibly offering a vast range of solutions that caters to the needs of all.</p>

                        <p>At 3's Deliveries, you have the freedom to choose from a wide range of services or customize the services to give you the best freight experience.</p>

                    </div>
                    <div class="col-12 col-lg-6 ml-lg-auto">
                        <div class="row">
                            <div class="col-12 col-sm-6">
                                <div class="card bg-primary text-white shadow-soft rounded mb-4">
                                    <div class="px-3 px-lg-4 py-5 text-center">
                                        <span class="icon icon-lg d-block"><i class="fas fa-user-shield text-white"></i></span>
                                         <h5>Safe and Affordable</h5>
                     <p class="mb-0 text-white">Enjoy safe deliveries @ competitive prices. </p>
                                    </div>
                                </div>
                                <div class="card bg-secondary text-white shadow-soft rounded mb-4">
                                    <div class="px-3 px-lg-4 py-5 text-center">
                                        <span class="icon icon-lg d-block"><i class="fas fa-fire text-white"></i></span>
                                        <h5>220+</h5>
                     <p class="mb-0 text-white">Shipping countries</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 pt-lg-4">
                                <div class="card bg-secondary m-bg-primary text-white shadow-soft rounded mb-4">
                                    <div class="px-3 px-lg-4 py-5 text-center">
                                        <span class="icon icon-lg d-block"><i class="fas fa-lightbulb text-white"></i></span>
                                         <h5>2-4 days</h5>
                     <p class="mb-0 text-white">Average delivery time</p>
                                    </div>
                                </div>
                                <div class="card bg-primary m-bg-secondary text-white shadow-soft rounded mb-4">
                                    <div class="px-3 px-lg-4 py-5 text-center">
                                        <span class="icon icon-lg d-block"><i class="fas fa-shapes text-white"></i></span>
                                        <h5>Real-time Shipment Tracking</h5>
                     <p class="mb-0 text-white">Through tracking details</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

   <!--about section start-->
   <section class="section section-lg bg-grayed about-section">
      <div class="container">
         <div class="row justify-content-between align-items-center">
            <div class="col-md-12 col-lg-6 mb-4 mb-md-4 mb-lg-0">
               <div class="card bg-primary position-relative  shadow-lg fancy-radius p-3">
                  <div class="dot-shape-top position-absolute">
                     <img src="/img/common/color-shape.png" alt="dot" class="img-fluid">
                  </div>
                  <img class="fancy-radius img-fluid" src="/img/abt-us.png" alt="modern desk">
                  <div class="dot-shape position-absolute bottom-0">
                     <img src="/img/dot-shape.png" alt="dot">
                  </div>
               </div>
            </div>
            <div class="col-md-12 col-lg-5">
               <div class="video-promo-content">
                  <h2>About Us</h2>
                  <p>
                     Be it a special surprise for your loved one, or an important work consignment, 3's Deliveries is at your service to deliver the quickest. 
                  </p>

                  <p>We provide an end-to-end supply chain with hassle-free logistic services, both domestic and international. Our services include - Freight Forwarding, Custom Clearance, Air Door To Door International Courier Services, Sea Freight, LCL & FCL, and First to Last-Mile Delivery of Products.</p>

                  <a href="/about" class="btn btn-primary mt-3">Know More</a>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--about section end-->
  
   <!--services section start-->
   <section class="section services-section ptb-100">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-md-8">
               <div class="section-heading text-center mb-5">
                  <h2>Our Services</h2>
                  <p>Your Needs, Our Services</p>
               </div>
            </div>
         </div>
         <div class="row services-row">
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/FOOD & PERSONAL ITEMS.png">
                     <h3 class="h6">FOOD & PERSONAL ITEMS</h3>
                     <p>Offering delivery of homemade delicacies, personal items, etc.</p>
                  </div>
               </div>
            </div>
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/AIR FREIGHT.png">
                     <h3 class="h6">AIR FREIGHT</h3>
                     <p>We offer door-to-door international delivery services through air. </p>
                  </div>
               </div>
            </div>
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/CUSTOMS CLEARANCE.png">
                     <h3 class="h6">CUSTOMS CLEARANCE</h3>
                     <p>Offering quality international custom clearance facility and services as per global standards.</p>
                  </div>
               </div>
            </div>
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/SEA FREIGHT.png">
                     <h3 class="h6">SEA FREIGHT</h3>
                     <p>We offer international courier and cargo shipment through the sea in LCL and FCL.</p>
                  </div>
               </div>
            </div>
            <div class="mb-4 mb-md-4 col-md-4">
               <div class="services-single d-flex icoo-div">
                  <div class="services-content-wrap">
                     <img src="/img/icon/SPECIAL SERVICES.png">
                     <h3 class="h6">SPECIAL SERVICES</h3>
                     <p>Offering domestic and international shipping on medicines, pets, and other items. </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--services section end-->
  
   <?php echo $__env->make('section.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
</div>

<?php echo $__env->make('section.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/benfy/public_html/testing/deliveries/web/resources/views/pages/home.blade.php ENDPATH**/ ?>