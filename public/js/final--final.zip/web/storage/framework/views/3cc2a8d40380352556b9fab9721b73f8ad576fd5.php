<?php $__env->startSection('content'); ?>

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">UPS</h1> 
                        <a href="/export/ups" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Export Data</a>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">

                        <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/upload/file/dhl')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="file-upload">
                                <button class="file-upload-btn" type="button" onclick="$('.file-upload-input').trigger( 'click' )">Upload CSV</button>
                                <div class="image-upload-wrap">
                                    <input class="file-upload-input" type="file" name="select_file" onchange="readURL(this);" />
                                    <div class="drag-text">
                                    <h3>Drag and drop a CSV or select add CSV</h3>
                                    </div>
                                </div>
                                <div class="file-upload-content">
                                    <img class="file-upload-image" src="#" alt="your image" />
                                    <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                        Upload
                                    </button>
                                </div>
                            </div>

                        </form>

                        </div>
                    </div>




                

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rene/Desktop/old/qs/resources/views/admin/pages/ups.blade.php ENDPATH**/ ?>