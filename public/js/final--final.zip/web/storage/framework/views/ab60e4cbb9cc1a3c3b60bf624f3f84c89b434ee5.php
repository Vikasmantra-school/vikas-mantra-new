 <!-- <?php if(Route::has('login')): ?>
    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Dashboard</a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

            <?php if(Route::has('register')): ?>
                <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php endif; ?> -->
<header class="header position-relative z-9">

    <nav class="navbar navbar-expand-lg fixed-top headroom">

        <div class="container position-relative">

            <a class="navbar-brand mr-lg-3" href="/">

                <img class="navbar-brand-dark" src="/img/logo/logo.png" alt="menuimage">

                <!-- <img class="navbar-brand-light" src="/img/logo/logo.png" alt="menuimage"> -->

            </a>

            <div class="navbar-collapse collapse" id="navbar-default-primary">

                <div class="navbar-collapse-header">

                    <div class="row">

                        <div class="col-6 collapse-brand">

                            <a href="#">

                                <img src="/img/logo/logo.png" alt="menuimage">

                            </a>

                        </div>

                        <div class="col-6 collapse-close">

                            <i class="fas fa-times" data-toggle="collapse" role="button"

                            data-target="#navbar-default-primary" aria-controls="navbar-default-primary"

                            aria-expanded="false" aria-label="Toggle navigation"></i>

                        </div>

                    </div>

                </div>

                <ul class="navbar-nav navbar-nav-hover ml-auto">


                    <li class="nav-item"><a class="nav-link" href="/">Home</a></li>


                    <li class="nav-item"><a class="nav-link" href="/about">About Us</a></li>


                    <li class="nav-item"><a class="nav-link" href="/services">Services</a></li>


                    <li class="nav-item"><a class="nav-link" href="/faq">FAQ's</a></li>


                    <li class="nav-item"><a class="nav-link" href="/contact-us">Contact Us</a></li>

                    <?php if(Auth::check()): ?>

                        <li class="nav-item">
                            <a class="nav-link">
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                        this.closest(\'form\').submit();']]); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                        this.closest(\'form\').submit();']); ?>
                                        <?php echo e(__('Log Out')); ?>

                                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </form>
                            </a>
                        </li>

               

                    <?php endif; ?>

                    

                </ul>

            </div>

            <div class="d-flex align-items-center">

                <button class="navbar-toggler ml-2" type="button" data-toggle="collapse" data-target="#navbar-default-primary" aria-controls="navbar-default-primary" aria-expanded="false" aria-label="Toggle navigation">

                    <span class="navbar-toggler-icon"></span>

                </button>

            </div>

        </div>

    </nav>

</header>

<?php /**PATH /home/benfy/public_html/testing/deliveries/web/resources/views/layouts/header.blade.php ENDPATH**/ ?>