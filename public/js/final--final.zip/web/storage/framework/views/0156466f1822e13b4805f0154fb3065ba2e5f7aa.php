<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php if(is_array(session('success'))): ?>
        <ul>
            <?php $__currentLoopData = session('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <?php echo e(session('success')); ?>

    <?php endif; ?>
</div>
<?php endif; ?><?php /**PATH /home/benfy/public_html/testing/deliveries/web/resources/views/admin/components/success.blade.php ENDPATH**/ ?>