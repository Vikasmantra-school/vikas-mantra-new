<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fdx_Weight extends Model
{
    use HasFactory;

    protected $table = "weights_fedex";

    protected $primaryKey = 'id';

    protected $fillable = [
        'weight',
        'zone_1',
        'zone_2',
        'zone_3',
        'zone_4',
        'zone_5',
        'zone_6',
        'zone_7',
        'zone_8',
        'zone_9',
        'zone_10',
        'zone_11',
        'zone_12',
        'zone_13',
        'zone_14',
        'type',
    ];
}
