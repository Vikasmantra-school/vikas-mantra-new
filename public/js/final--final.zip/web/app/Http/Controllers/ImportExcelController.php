<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Weight;
use App\Models\Dhl_Weight;
use App\Models\Fdx_Weight;
use App\Models\Zone;
use App\Models\Location;
use Rap2hpoutre\FastExcel\FastExcel;

class ImportExcelController extends Controller
{

    public function import(Request $request){
        $filename = $request->file('select_file')->getClientOriginalName();
        $request->file('select_file')->storeAs('public/xlsx', $filename);
        $path = public_path('../storage/app/public/xlsx/'.$filename);

        Weight::query()->delete();
    
        $weights = (new FastExcel)->import($path, function ($line) {
            return Weight::create(
                ['weight' => $line['weight'],
                'zone_1' => $line['zone_1'],
                'zone_2' => $line['zone_2'],
                'zone_3' => $line['zone_3'],
                'zone_4' => $line['zone_4'],
                'zone_5' => $line['zone_5'],
                'zone_6' => $line['zone_6'],
                'zone_7' => $line['zone_7'],
                'zone_8' => $line['zone_8'],
                'zone_9' => $line['zone_9'],
                'zone_10' => $line['zone_10'],
                'zone_11' => $line['zone_11'],
                'zone_12' => $line['zone_12'],
                'zone_13' => $line['zone_13'],
                'zone_14' => $line['zone_14'],
                'type' => $line['type']],
            );
        });
        return back()->with(['success' => "Weights updated successfully."]);
    }

    public function dhl(Request $request){
        $filename = $request->file('select_file')->getClientOriginalName();
        $request->file('select_file')->storeAs('public/xlsx', $filename);
        $path = public_path('../storage/app/public/xlsx/'.$filename);

        Dhl_Weight::query()->delete();

        $weights = (new FastExcel)->import($path, function ($line) {
            return Dhl_Weight::create(
                [
                	'weight' => $line['weight'],
	                'zone_1' => $line['zone_1'],
	                'zone_2' => $line['zone_2'],
	                'zone_3' => $line['zone_3'],
	                'zone_4' => $line['zone_4'],
	                'zone_5' => $line['zone_5'],
	                'zone_6' => $line['zone_6'],
	                'zone_7' => $line['zone_7'],
	                'zone_8' => $line['zone_8'],
	                'zone_9' => $line['zone_9'],
	                'zone_10' => $line['zone_10'],
	                'zone_11' => $line['zone_11'],
	                'zone_12' => $line['zone_12'],
	                'zone_13' => $line['zone_13'],
	                'zone_14' => $line['zone_14'],
	                'type' => $line['type']
	            ],
            );
        });
        return back()->with(['success' => "Weights updated successfully."]);


        // $request->validate([
        //     'file' => 'required|mimes:pdf,xlx,csv|max:2048',
        // ]);
  
        // $fileName = time().'.'.$request->file->extension();  
   
        // $request->file->move(public_path('uploads'), $fileName);
   
        // return back()
        //     ->with('success','You have successfully upload file.')
        //     ->with('file',$fileName);

        // return $request->file('select_file')->store('docs');            
    }

    //

    public function fdx(Request $request){
        $filename = $request->file('select_file')->getClientOriginalName();
        $request->file('select_file')->storeAs('public/xlsx', $filename);
        $path = public_path('../storage/app/public/xlsx/'.$filename);

        Fdx_Weight::query()->delete();

        $weights = (new FastExcel)->import($path, function ($line) {
            return Fdx_Weight::create(
                ['weight' => $line['weight'],
                'zone_1' => $line['zone_1'],
                'zone_2' => $line['zone_2'],
                'zone_3' => $line['zone_3'],
                'zone_4' => $line['zone_4'],
                'zone_5' => $line['zone_5'],
                'zone_6' => $line['zone_6'],
                'zone_7' => $line['zone_7'],
                'zone_8' => $line['zone_8'],
                'zone_9' => $line['zone_9'],
                'zone_10' => $line['zone_10'],
                'zone_11' => $line['zone_11'],
                'zone_12' => $line['zone_12'],
                'zone_13' => $line['zone_13'],
                'zone_14' => $line['zone_14'],
                'type' => $line['type']],
            );
        });
        return back()->with(['success' => "Weights updated successfully."]);
    }

    public function zones(Request $request){
        $filename = $request->file('select_file')->getClientOriginalName();
        $request->file('select_file')->storeAs('public/xlsx', $filename);
        $path = public_path('../storage/app/public/xlsx/'.$filename);

        Zone::query()->delete();

        $weights = (new FastExcel)->import($path, function ($line) {
            return Zone::create(
                [
                    'destination' => $line['destination'],
                    'zone_name' => $line['zone_name']
                ],
            );
        });
        return back()->with(['success' => "Zones updated successfully."]);
    }

    public function importLocations(Request $request){
        $filename = $request->file('select_file')->getClientOriginalName();
        $request->file('select_file')->storeAs('public/xlsx', $filename);
        $path = public_path('../storage/app/public/xlsx/'.$filename);

        Location::query()->delete();

        $locations = (new FastExcel)->import($path, function ($line) {
            return Location::create(
                [
                    'name' => $line['name'],
                    'address' => $line['address'],
                    'station_code' => $line['station_code'],
                    'location' => $line['location'],
                    'supervisor_name' => $line['supervisor_name'],
                    'phone_number' => $line['phone_number']
                ],
            );
        });
        return back()->with(['success' => "Locations updated successfully."]);
    }

    public function exportUps(){
        return (new FastExcel(Weight::all()))->download('ups.xlsx', function ($weight) {
            return [
                'weight' => $weight->weight,
                'zone_1' => $weight->zone_1,
                'zone_2' => $weight->zone_2,
                'zone_3' => $weight->zone_3,
                'zone_4' => $weight->zone_4,
                'zone_5' => $weight->zone_5,
                'zone_6' => $weight->zone_6,
                'zone_7' => $weight->zone_7,
                'zone_8' => $weight->zone_8,
                'zone_9' => $weight->zone_9,
                'zone_10' => $weight->zone_10,
                'zone_11' => $weight->zone_11,
                'zone_12' => $weight->zone_12,
                'zone_13' => $weight->zone_13,
                'zone_14' => $weight->zone_14,
                'type' => $weight->type,
            ];
        });
    }

    public function exportFedex(){
        return (new FastExcel(Fdx_Weight::all()))->download('fedex.xlsx', function ($weight) {
            return [
                'weight' => $weight->weight,
                'zone_1' => $weight->zone_1,
                'zone_2' => $weight->zone_2,
                'zone_3' => $weight->zone_3,
                'zone_4' => $weight->zone_4,
                'zone_5' => $weight->zone_5,
                'zone_6' => $weight->zone_6,
                'zone_7' => $weight->zone_7,
                'zone_8' => $weight->zone_8,
                'zone_9' => $weight->zone_9,
                'zone_10' => $weight->zone_10,
                'zone_11' => $weight->zone_11,
                'zone_12' => $weight->zone_12,
                'zone_13' => $weight->zone_13,
                'zone_14' => $weight->zone_14,
                'type' => $weight->type,
            ];
        });
    }

    public function exportDhl(){
        return (new FastExcel(Dhl_Weight::all()))->download('dhl.xlsx', function ($weight) {
            return [
                'weight' => $weight->weight,
                'zone1' => $weight->zone_1,
                'zone2' => $weight->zone_2,
                'zone3' => $weight->zone_3,
                'zone4' => $weight->zone_4,
                'zone5' => $weight->zone_5,
                'zone6' => $weight->zone_6,
                'zone7' => $weight->zone_7,
                'zone8' => $weight->zone_8,
                'zone9' => $weight->zone_9,
                'zone10' => $weight->zone_10,
                'zone11' => $weight->zone_11,
                'zone12' => $weight->zone_12,
                'zone13' => $weight->zone_13,
                'zone14' => $weight->zone_14,
                'type' => $weight->type,
            ];
        });
    }

    public function exportZones(){
        return (new FastExcel(Zone::all()))->download('zones.xlsx', function ($zone) {
            return [
                'zone_name' => $zone->zone_name,
                'destination' => $zone->destination
            ];
        });
    }

    public function exportLocations(){
        return (new FastExcel(Location::all()))->download('locations.xlsx', function ($location) {
            return [
                'name' => $location->name,
                'address' => $location->address,
                'station_code' => $location->station_code,
                'location' => $location->location,
                'supervisor_name' => $location->supervisor_name,
                'phone_number' => $location->phone_number,
            ];
        });
    }


}
