<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\User;
use Rap2hpoutre\FastExcel\FastExcel;

class ImportExcelController extends Controller
{
    public function import(Request $request){
        $this->validate($request,[
            'select_file' => 'required|mimes:xls,xlsx'
        ]);
        $path = $request->file('select_file')->getRealPath();
        $data = Excel::import($path)->get();

        if ($data->count() > 0 ){

            foreach($data->toArray() as $key => $value){
                foreach($value as $row){
                    $insert_data[] = array(
                        'Document' => $row['document']
                    );
                }
            }

            if(!empty($insert_data)){
                DB::table('document')->insert($insert_data);
            }
            return back()->with('success','Uploaded');

        }
    }
}
