<?php

namespace App\Http\Controllers;
use App\Models\Zone;
use App\Models\Country;
use App\Models\Weight;

use Illuminate\Http\Request;

class ZonesController extends Controller
{
    public function index(){
        $zones = Zone::find(2)->getCountry;
        return view('pages.home', ['zones' => $zones]);
        // dd($zones);
    }
}
