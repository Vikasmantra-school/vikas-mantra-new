<?php

namespace App\Http\Controllers;
use DB;
use App\Models\Country;
use App\Models\Weight;
use App\Models\Dhl_Weight;
use App\Models\Fdx_Weight;
use App\Models\Zone;
use App\Models\Location;
use App\Models\Type;
use App\Models\User;
use Response;
use Illuminate\Http\Request;
use Hash;
use Auth;


class WeightsController extends Controller
{
    public function index(){
        $weights = Dhl_Weight::all('weight');
        $zones = Zone::all();
        $types = Type::all();
        return view('pages.home')->with(compact('weights','zones','types'));
    }

    public function about(){
        return view('pages.about');
    }

    public function contact(){
        $locations = Location::all();
        return view('pages.contact')->with(compact('locations'));
    }

    public function getRates(Request $request, $id, $id2, $id3){

        $weights =  DB::table('weights_ups')
        ->select('weights_ups.'.$id)
        ->crossJoin('zones')
        ->where(['weights_ups.weight' => $id2,'weights_ups.type' => $id3])
        ->get();
        $weights_count =  DB::table('weights_ups')
        ->select('weights_ups.'.$id)
        ->crossJoin('zones')
        ->where(['weights_ups.weight' => $id2,'weights_ups.type' => $id3])
        ->count();
        //

        $weights_dhl = DB::table('weights_dhl')
        ->select('weights_dhl.'.$id)
        ->crossJoin('zones')
        ->where(['weights_dhl.weight' => $id2,'weights_dhl.type' => $id3])
        ->get();
        $weights_dhl_count = DB::table('weights_dhl')
        ->select('weights_dhl.'.$id)
        ->crossJoin('zones')
        ->where(['weights_dhl.weight' => $id2,'weights_dhl.type' => $id3])
        ->count();

        $weights_fedex =  DB::table('weights_fedex')
        ->select('weights_fedex.'.$id)
        ->crossJoin('zones')
        ->where(['weights_fedex.weight' => $id2,'weights_fedex.type' => $id3])
        ->get();
        $weights_fedex_count =  DB::table('weights_fedex')
        ->select('weights_fedex.'.$id)
        ->crossJoin('zones')
        ->where(['weights_fedex.weight' => $id2,'weights_fedex.type' => $id3])
        ->count();

        // $r = Response::json(array(
        //     $weights[1]->$id,
        //     $weights_dhl[1]->$id,
        //     $weights_fedex[1]->$id
        // ));
        // return $r;
        // $dhl = Response::json($weights_dhl[1]->$id);

        if($weights_count < 1 && $weights_dhl_count >= 1 && $weights_fedex_count >= 1){
            $r = Response::json(array(
                '-',
                $weights_dhl[1]->$id,
                $weights_fedex[1]->$id
            ));
            return $r;
        }


        // fdx
        elseif($weights_count < 1 && $weights_dhl_count < 1 && $weights_fedex_count >= 1){
            $r = Response::json(array(
                '-',
                '-',
                $weights_fedex[1]->$id
            ));
            return $r;
        }
        elseif($weights_count >= 1 && $weights_dhl_count < 1 && $weights_fedex_count >= 1){
            $r = Response::json(array(
                $weights[1]->$id,
                '-',
                $weights_fedex[1]->$id
            ));
            return $r;
        }
        elseif($weights_count < 1 && $weights_dhl_count >= 1 && $weights_fedex_count >= 1){
            $r = Response::json(array(
                '-',
                $weights_dhl[1]->$id,
                $weights_fedex[1]->$id
            ));
            return $r;
        }
        // fdx

        elseif($weights_count >= 1 && $weights_dhl_count >= 1 && $weights_fedex_count < 1){
            $r = Response::json(array(
                $weights[1]->$id,
                $weights_dhl[1]->$id,
                '-'
            ));
            return $r;
        }

        elseif($weights_count < 1 && $weights_dhl_count < 1 && $weights_fedex_count < 1){
            $r = Response::json(array(
                '-',
                '-',
                '-'
            ));
            return $r;
        }

        else{
            $r = Response::json(array(
                $weights[1]->$id,
                $weights_dhl[1]->$id,
                $weights_fedex[1]->$id
            ));
            return $r;
        }

    }

    public function dhl(){
        $dhls = Dhl_Weight::all();
        return view('admin.pages.dhl')->with(compact('dhls'));
    }

    public function fedex(){
        $fedex = Fdx_Weight::all();
        return view('admin.pages.fedex')->with(compact('fedex'));
    }

    public function ups(){
        $ups = Weight::all();
        return view('admin.pages.ups')->with(compact('ups'));
    }

    public function zones(){
        $zones = Zone::all();
        return view('admin.pages.zones')->with(compact('zones'));
    }

    public function profile(){
        $users = User::all();
        return view('admin.pages.profile')->with(compact('users'));
    }

    public function profileUpdate(Request $request, $id){
        // $users = User::all();
        // return view('admin.pages.profile')->with(compact('users'));
        // $us = $id;
        // return $us;

        User::where('id', $id)
            ->update(
                ['email' => $request->input('email'),
                'name' => $request->input('name')]
            ); 

        return redirect()->back()->with('success', 'Updated'); 


    }

    public function changePassword(){
        $users = User::all();
        return view('admin.pages.change-password')->with(compact('users'));
    }

     public function changePasswordPost(Request $request) {
        if (!(Hash::check($request->get('current-password'), Auth::user()->password))) {
            return redirect()->back()->with("error","Your current password does not matches with the password.");
            return 'one';
        }

        if(strcmp($request->get('current-password'), $request->get('new-password')) == 0){
            return redirect()->back()->with("error","New Password cannot be same as your current password.");
            return 'two';
        }

        // $validatedData = $request->validate([
        //     'current-password' => 'required',
        //     'new-password' => 'required|string|min:8|confirmed',
        // ]);

        $user = User::all();
        // $user->password = bcrypt($request->get('new-password'));
        // $user->save();

        return $user;


        // return redirect()->back()->with("success","Password successfully changed!");

    }

    public function getRatesTest(Request $request, $id, $id2, $id3){

        $weights =  DB::table('weights_ups')
        ->select('weights_ups.'.$id)
        ->crossJoin('zones')
        ->where(['weights_ups.weight' => $id2,'weights_ups.type' => $id3])
        ->pluck($id)
        ->toArray();
        $weights_count =  DB::table('weights_ups')
        ->select('weights_ups.'.$id)
        ->crossJoin('zones')
        ->where(['weights_ups.weight' => $id2,'weights_ups.type' => $id3])
        ->count();

        return $weights;
        // http://deliveries.benfy.co/test/zone_1/0.5/package

    }




}
 