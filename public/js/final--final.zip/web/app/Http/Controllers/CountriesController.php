<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Country;
use App\Models\Weight;

class CountriesController extends Controller
{
    public function test(){
        $weights = Weight::find(1)->getCountry();
        return $weights;
    }
}
