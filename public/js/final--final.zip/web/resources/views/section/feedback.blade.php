<!--team section start-->
   <section class="section section-sm feedback-section bg-grayed">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-lg-8">
               <div class="section-heading text-center mb-5">
                  <h3>Customer Testimonials</h3>
               </div>
            </div>
         </div>
         <div class="owl-carousel feedback-div">
            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Kumaresan Paulraj</h3>
                        <p class="card-text pt-4">Service was very great ! Fast and impressive.. So wonderful.. Keep up the good work !</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Ashwini N</h3>
                        <p class="card-text pt-4">Awesome service. Nice packaging for delicate items and safely delivered to my family.</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Samyuktha Venkatesan</h3>
                        <p class="card-text pt-4">Hi. Thank you for getting my package safely. Everything was neatly packed without leakage. Wonderful service !!! Very much recommend.</p>
                     </div>
                  </div>
               </div>
            </div>

            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Saravanan Parthasarathy</h3>
                        <p class="card-text pt-4">My sincere thanks to your service. My daughter received her parcel in good condition in UK. Everything was perfectly packed, and received in a few days time.</p>
                     </div>
                  </div>
               </div>
            </div>

            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Fahmidha Ashraf</h3>
                        <p class="card-text pt-4">Excellent service by the team. Great coordination by the members and all my items reached safely.</p>
                     </div>
                  </div>
               </div>
            </div>

            <div class="mb-md-4 mb-lg-0 mb-4 item">
               <div class="profile-card">
                  <div class="card shadow-sm animate-hover border-variant-soft">
                     <div class="card-body p-4">
                        <h3 class="h5 mb-2">Christopher Jonathan</h3>
                        <p class="card-text pt-4">Highly recommend 3S Deliveries for their services. Excellent service…. Definitely will be using their services for future shipments…</p>
                     </div>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </section>
   <!--team section end-->
