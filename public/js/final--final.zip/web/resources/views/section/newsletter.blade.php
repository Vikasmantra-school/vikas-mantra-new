<!--cta section start-->
<section class="section section-sm bg-dark-blue">
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-12 col-lg-7 text-center">
               <div class="subscribe-content">
                  <span class="modal-icon icon icon-lg text-primary d-none d-md-block d-lg-block"><i class="fas fa-envelope-open-text"></i></span>
                  <h2 class="h4 modal-title my-2">Join our monthly news letter</h2>
                  <p class="mb-4">Get exclusive supply-chain and logistics news and updates from around the world.</p>
               </div>
               <div class="form-group">
                  <div class="d-sm-flex flex-column flex-sm-row mb-3 justify-content-center">
                     <input type="text" id="inputYourMail" placeholder="Enter your email address here" class="mr-sm-1 mb-2 mb-sm-0 form-control form-control-lg">
                     <button type="submit" class="ml-sm-1 btn btn-secondary">Subscribe</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!--cta section end-->