@foreach($types as $type)
   <div id="myModal-{{$type->name}}" class="modal weight-c modals">
      <div class="modal-content">
         <div class="modal-header">
            <h3>Your Quote from India to <span class="destination"></span></h3>
            <span class="close">&times;</span>
         </div>
         <table>
            <tr class="tr-header">
               <th>Services</th>
               <th>Weight</th>
               <th>Charges</th>
               <th>Book your order</th>
            </tr>

            <tr class="ups-div">
               <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
               <td class="ups"></td>
               <td class="appendata"></td>
               <td>
                  <div>
                     <a href="https://api.whatsapp.com/send?phone=+917837775999&text=Send a quote"><img src="/img/icon/whatsapp.png" alt=""></a>
                     <a href="mailto:ops3sdeliveries@gmail.com,customercare3sdeliveries@gmail.com?subject=Query regarding shipment&body=Please share you details below for a call back.%0DName -%0DContact number -"><img src="/img/icon/mail.png" alt=""></a>
                  </div>
               </td>
            </tr>

            <tr class="dhl-div">
               <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
               <td class="dhl"></td>
               <td class="dhlRate"></td>
               <td>
                  <div>
                     <a href="https://api.whatsapp.com/send?phone=+917837775999&text=Send a quote"><img src="/img/icon/whatsapp.png" alt=""></a>
                     <a href="mailto:ops3sdeliveries@gmail.com,customercare3sdeliveries@gmail.com?subject=Query regarding shipment&body=Please share you details below for a call back.%0DName -%0DContact number -"><img src="/img/icon/mail.png" alt=""></a>
                  </div>
               </td>
            </tr>

            <tr class="fdx-div">
               <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
               <td class="fdx"></td>
               <td class="fdxRate"></td>
               <td>
                  <div>
                     <a href="https://api.whatsapp.com/send?phone=+917837775999&text=Send a quote"><img src="/img/icon/whatsapp.png" alt=""></a>
                     <a href="mailto:ops3sdeliveries@gmail.com,customercare3sdeliveries@gmail.com?subject=Query regarding shipment&body=Please share you details below for a call back.%0DName -%0DContact number -"><img src="/img/icon/mail.png" alt=""></a>
                  </div>
               </td>
            </tr>

            <!-- <ol>

               <li>TERMS & CONDITIONS</li>                       
               <li>GST as applicable</li>   
               <li>WEIGHT INFORMATION</li>         
               <li>Piece wise weight rounded off to next 500 grams, actual weight or Dims weight whichever is higher will be considered</li>         
               <li>Any fraction of a kilo will consider for next higher weight.</li>                 
               <li>Dimensional weight in kg= Length x Height x Width in CMS /5000   </li>             
               <li>SPECIAL HANDLING FEES IN INDIAN RUPEES</li>        
               <li>A Surchage apllicable for the shipment conatining any packages that Dim: Rs. 1250 + +</li>  
               <li>Measure greater than 122 CMS along its Second longestside</li>               
               <li>Measure greter than 76 CMS along its longest side</li> 
               <li>Non Stackable Charges Rs.11565 ++</li>         
               <li>Address Correction: Rs.750/- + +   </li>
               <li>Saturday Delivery in USA: Rs.1500/- + +  </li>
               <li>COMMERCIAL SHIPMENTS      </li>    
               <li>A customs clearance charge of Rs. 1750+ GST per shipment  </li>              
               <li>BSO Charges Rs.600/- (BROKER SELECTION OPTION ) + + </li>        
               <li>if Any Return Shipment Will Be Charged as per ups Invoice </li>                 
               <li>All International Shipments Cliams are Subject to ups Coditions of Carriage   </li>                  
               <li>Rates may be amend without any prior notice              </li>
               <li>ups RRT ( Re Route Charges) in US and applicable Countries will be as per ups Invoice                       </li>
               <li>One Pcs 68 Kgs Shipment will be Billed as an 71 Kgs Slab Rates  </li>              
               <li>For IPF shipments highest weight minimum 70 kgs would consider for all multi piece shipments </li>   
               <li>Example one pc 70 kg other 20 kgs Both Pcs weight will be Consider 70 + 70 kg 140 kg</li> 

            </ol>  -->           

         </table>
      </div>
   </div>
@endforeach