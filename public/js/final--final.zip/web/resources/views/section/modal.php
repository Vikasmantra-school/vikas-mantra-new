
@foreach($types as $type)
   <div id="myModal-{{$type->name}}" class="modal weight-c">
      <div class="modal-content">
         <div class="modal-header">
            <h3>Your Quote from India to <span id="destination-{{$type->name}}"></span></h3>
            <span class="close-{{$type->name}}">&times;</span>
         </div>
         <table>
            <tr class="tr-header">
               <th>Services</th>
               <th>Weight</th>
               <th>Charges</th>
               <th>Book your order</th>
            </tr>

            <tr class="ups-div-{{$type->name}}">
               <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
               <td id="ups-{{$type->name}}}"></td>
               <td id="appendata-{{$type->name}}}"></td>
               <td>
                  <div>
                     <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                     <a href=""><img src="/img/icon/mail.png" alt=""></a>
                  </div>
               </td>
            </tr>

            <tr class="dhl-div-{{$type->name}}">
               <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
               <td id="dhl-{{$type->name}}}"></td>
               <td id="dhlRate-{{$type->name}}"></td>
               <td>
                  <div>
                     <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                     <a href=""><img src="/img/icon/mail.png" alt=""></a>
                  </div>
               </td>
            </tr>

            <tr class="fdx-div-{{$type->name}}">
               <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
               <td id="fdx-{{$type->name}}"></td>
               <td id="fdxRate-{{$type->name}}"></td>
               <td>
                  <div>
                     <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                     <a href=""><img src="/img/icon/mail.png" alt=""></a>
                  </div>
               </td>
            </tr>

         </table>
      </div>
   </div>
@endforeach