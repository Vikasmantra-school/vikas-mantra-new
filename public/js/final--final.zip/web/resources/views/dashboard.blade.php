
@extends('layouts.app')
@section('content')
<div class="main">
   <!--hero section start-->
   <section class="section weight-calc pt-9 pb-9 section-header" style="">
      <div class="container">
         <div class="row align-items-center">
            
            <div class="col-md-5 col-lg-6 form-divv">
               <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                  <li class="nav-item" role="presentation">
                     <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">UPS</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">DHL</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">FEDEX</a>
                  </li>
                  <li class="nav-item" role="presentation">
                     <a class="nav-link" id="pills-zones-tab" data-toggle="pill" href="#pills-zones" role="tab" aria-controls="pills-zones" aria-selected="false">Zones</a>
                  </li>
               </ul>
               <div class="tab-content" id="pills-tabContent">
                  <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">

                    @if(count($errors) > 0)

                        <ul>    
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>

                    @endif

                    @if($message = Session::get('success'))
                        {{ $message }}
                    @endif

                    @if(session('success'))
                        <strong>{{session('success')}}</strong>
                    @endif
                     <form method="post" enctype="multipart/form-data" action="{{ url('/upload/file') }}">
                        @csrf
                        <input type="hidden" name="type" value="package" id="type">
                        <div class="container">
                            <div class="row">

                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Select File</label>
                                            <input type="file" name="select_file"/>
                                        </div>

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Upload</label>
                                            <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                                Upload
                                            </button>
                                        </div>

                                    </div>
                                </div>

                                <p>
                                    <a href="{{ url('export') }}">Export Users</a>
                                </p>

                            </div>
                        </div>
                     </form>
                  </div>

                  <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                  <form method="post" enctype="multipart/form-data" action="{{ url('/upload/file/dhl') }}">
                        @csrf
                        <div class="container">
                            <div class="row">

                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Select File</label>
                                            <input type="file" name="select_file"/>
                                        </div>

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Upload</label>
                                            <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                                Upload
                                            </button>
                                        </div>

                                    </div>
                                </div>

                                <p>
                                    <a href="{{ url('export') }}">Export Users</a>
                                </p>

                            </div>
                        </div>
                     </form>

                  </div>

                  <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                  <form method="post" enctype="multipart/form-data" action="{{ url('/upload/file/fdx') }}">
                        @csrf
                        <div class="container">
                            <div class="row">

                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Select File</label>
                                            <input type="file" name="select_file"/>
                                        </div>

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Upload</label>
                                            <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                                Upload
                                            </button>
                                        </div>

                                    </div>
                                </div>

                                <p>
                                    <a href="{{ url('export') }}">Export Users</a>
                                </p>

                            </div>
                        </div>
                     </form>
                  </div>
                  <!-- // -->

                  <div class="tab-pane fade" id="pills-zones" role="tabpanel" aria-labelledby="pills-zones-tab">
                    <form method="post" enctype="multipart/form-data" action="{{ url('/upload/file/zones') }}">
                        @csrf
                        <div class="container">
                            <div class="row">

                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Select File</label>
                                            <input type="file" name="select_file"/>
                                        </div>

                                        <div class="col-md-6 pl-0 select-div">
                                            <label for="from">Upload zones </label>
                                            <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                                Upload
                                            </button>
                                        </div>

                                    </div>
                                </div>

                                <p>
                                    <a href="{{ url('export') }}">Export Users</a>
                                </p>

                            </div>
                        </div>
                     </form>
                  </div>

                  <!-- // -->

               </div>
            </div>
         </div>
      </div>
   </section>

    <section class="section weight-calc pt-9 pb-9 section-header" style="">
        <div class="container">

            <div class="row align-items-center">
            
                <div class="col-md-12 col-lg-12">
                    
                    <table>
                        <tr class="tr-header">
                            <th></th>
                        </tr> 

                        <tr>
                            <td></td>
                        </tr>

                    </table>
                </div>

            </div>
        </div>
    </section>

   

</div>

@endsection