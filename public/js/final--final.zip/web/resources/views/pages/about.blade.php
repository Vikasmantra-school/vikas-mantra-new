@extends('layouts.app')
@section('content')
<div class="main">
  <section class="pages-banner">
            <div class="section-lg section-header primary-bg" style="    padding-bottom: 83px;">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>About Us</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">About Us</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
  
   <!--about section start-->
   <section class="section">
      <div class="container">
         <div class="row justify-content-between align-items-center">
          
            <div class="col-md-12 col-lg-12">
               <div class="video-promo-content">
                  <h2>Bridging The Gap Between You And Your Priorities</h2>

                  <p>We provide an end-to-end supply chain with hassle-free logistic services, both domestic and international. Our services include Freight Forwarding, Custom Clearance, Air Door To Door International Courier Services, Sea Freight, LCL & FCL, and First to Last-Mile Delivery of Products.
                  </p>

                  <p>We at 3's Deliveries is a group of experienced logistics professionals, who have worked with the best of companies such as FedEx, UPS, Samsung, & Amazon. With an experience of over 20 years in the International and Domestic Logistics System in numerous areas ranging from International Express, Manufacturing to E-Commerce, Freight Forwarding, etc, we believe in providing the best services to meet our customers’ needs and provide them with complete logistics solutions.</p>

                  <p>Our team is committed to providing timely delivery with shipping at the best rates, customising solutions for individual customers and businesses, with a variety of transport modes and services at one place. 3's Deliveries takes pride in providing quality international services for more than 15+ years.</p>

                  <p>We partner with top business players in the field of freight forwarding including the likes of FedEx, DHL, UPS, etc.</p>

                  <p>In the real world, customers have to go through immense difficulties and have to take numerous steps to ensure the safe delivery of their parcels. Some of these issues include the items that can be shipped and that can't, risks involved in customs clearance, difficulties in finding services at reasonable prices, and the lack of customer care support from logistics companies, etc.</p>

                  <p>3's Deliveries has been established by taking into account these considerations and the requirements of the customers. We ensure customer-friendly processes right from booking a parcel to delivering it.</p>

               </div>
            </div>
         </div>
      </div>
   </section>
   <!--about section end-->
  
   @include('section.feedback')
   
</div>
<div id="myModal" class="modal weight-c">
   <div class="modal-content">
      <div class="modal-header">
         <h3>Your Quote from India to <span id="destination"></span></h3>
         <span class="close">&times;</span>
      </div>
      <table>
         <tr class="tr-header">
            <th>Services</th>
            <th>Weight</th>
            <th>Charges</th>
            <th>Book your order</th>
         </tr>

         <tr>
            <td><img class="courier" src="/img/ups.jpeg" alt=""></td>
            <td id="ups"></td>
            <td id="appendata"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/fedex.jpeg" alt=""></td>
            <td id="dhl"></td>
            <td id="dhlRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

         <tr>
            <td><img class="courier" src="/img/dhl.jpeg" alt=""></td>
            <td id="fdx"></td>
            <td id="fdxRate"></td>
            <td>
               <div>
                  <a href=""><img src="/img/icon/whatsapp.png" alt=""></a>
                  <a href=""><img src="/img/icon/mail.png" alt=""></a>
               </div>
            </td>
         </tr>

      </table>
   </div>
</div>
@endsection