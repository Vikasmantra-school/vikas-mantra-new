<style>
   .admin.logo{
    width: 158px;
    height: auto;
    }

    .sidebar .sidebar-brand {
    padding: 52px 33px;
    }
</style>
<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="/dashboard">
    <img class="admin logo" src="/img/white-logo.png" alt="menuimage">
</a>


<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="/dashboard/services/dhl">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Couriers
</div>

<li class="nav-item">
    <a class="nav-link" href="/dashboard/services/dhl">
        <i class="fas fa-fw fa-truck"></i>
        <span>DHL</span>
    </a>
</li>

<li class="nav-item">
    <a class="nav-link" href="/dashboard/services/fedex">
        <i class="fas fa-fw fa-truck"></i>
        <span>Fedex</span>
    </a>
</li>

<li class="nav-item">
    <a class="nav-link" href="/dashboard/services/ups">
        <i class="fas fa-fw fa-truck"></i>
        <span>UPS</span>
    </a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Zones
</div>

<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="/dashboard/zones">
        <i class="fas fa-fw fa-globe"></i>
        <span>Zones</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Contact
</div>

<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="/dashboard/locations">
        <i class="fas fa-fw fa-map"></i>
        <span>Locations</span></a>
</li>


<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>


</ul>
<!-- End of Sidebar -->