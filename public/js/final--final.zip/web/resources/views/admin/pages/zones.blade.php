@extends('layouts.admin-theme')
@section('content')

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Zones</h1> 
                        <a href="/export/zones" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Export Data</a>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">

                        <form method="post" enctype="multipart/form-data" action="{{ url('/upload/file/zones') }}">
                            @csrf
                            <div class="file-upload">
                                <button class="file-upload-btn" type="button" onclick="$('.file-upload-input').trigger( 'click' )">Browse Files</button>
                                <div class="image-upload-wrap">
                                    <input class="file-upload-input" id="upload_file" type="file" name="select_file" onchange="readURL(this);" />
                                    <div class="drag-text">
                                    <h3>Or Drag & Drop Xlsx here</h3>
                                    </div>
                                </div>
                                <div class="file-upload-content">

                                    <div class="upload_container">
                                        <p class="image-title mb-0"></p>
                                        <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                            Upload
                                            <i class="fas fa-upload fa-sm text-white-50"></i>
                                        </button>
                                    </div>

                                </div>
                            </div>

                        </form>

                        </div>
                    </div>

<!-- Data -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Zone Data</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Zone Name</th>
                        <th>Destination</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Zone Name</th>
                        <th>Destination</th>
                    </tr>
                </tfoot>
                <tbody>
                    @foreach($zones as $zone)
                    <tr>
                        <td>{{$zone->zone_name}}</td>
                        <td>{{$zone->destination}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>



                

@endsection