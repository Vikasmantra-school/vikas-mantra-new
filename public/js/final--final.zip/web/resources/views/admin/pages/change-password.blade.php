@extends('layouts.admin-theme')
@section('content')

    <!-- Page Heading -->
    <div class="d-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            Change Password

        </h1> 
    </div>

    <div class="row">

        <div class="col-12 col-lg-7 offset-lg-2">

            <div class="form-card card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-12">
                            <div class="p-5">

                                <form class="user" method="post" action="/profile/change-password-post">

                                    @csrf

                                    <div class="form-group row">
                                        <div class="col-sm-12 mb-3 mb-sm-0">
                                            <label for="current-password">Your Current Password</label>
                                            <input id="current-password" type="password" class="form-control form-control-user"
                                                placeholder="" name="current-password" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-12 mb-3 mb-sm-0">
                                            <label for="new-password">New Password</label>
                                            <input id="new-password" type="password" class="form-control form-control-user"
                                                placeholder="" name="new-password" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-12 mb-3 mb-sm-0">
                                            <label for="confirm-new-password">Confirm New Password</label>
                                            <input id="confirm-new-password" type="password" class="form-control form-control-user"
                                                placeholder="" name="confirm-new-password" required>
                                        </div>
                                    </div>
                                  
                                    <button class="btn btn-primary btn-user btn-block" type="submit">
                                        Change Password
                                    </button>

                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="col-12">
            @if (\Session::has('error'))
                <div class="alert alert-danger">
                    <ul>
                        <li>{!! \Session::get('error') !!}</li>
                    </ul>
                </div>
            @endif
        </div>

        <div class="col-12">
            @if (\Session::has('success'))
                <div class="alert alert-success">
                    <ul>
                        <li>{!! \Session::get('success') !!}</li>
                    </ul>
                </div>
            @endif
        </div>


    </div>
            

@endsection