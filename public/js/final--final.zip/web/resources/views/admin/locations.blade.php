@extends('layouts.admin-theme')
@section('content')

 <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Locations</h1> 
        <a href="/export/locations" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Export Data</a>
    </div>

    @include('admin.components.success')

    <div class="row">
                <div class="col-sm-12">
                    <form method="post" enctype="multipart/form-data" action="{{ url('/upload/file/locations') }}">
                        @csrf
                        <div class="file-upload">
                            <button class="file-upload-btn" type="button" onclick="$('.file-upload-input').trigger( 'click' )">Browse Files</button>
                            <div class="image-upload-wrap">
                                <input class="file-upload-input" id="upload_file" type="file" name="select_file" onchange="readURL(this);" />
                                <div class="drag-text">
                                <h3>Or Drag & Drop Xlsx here</h3>
                                </div>
                            </div>
                            <div class="file-upload-content">

                                <div class="upload_container">
                                    <p class="image-title mb-0"></p>
                                    <button class="btn btn-primary" type="submit" name="upload" value="upload">
                                        Upload
                                        <i class="fas fa-upload fa-sm text-white-50"></i>
                                    </button>
                                </div>

                            </div>
                        </div>

                    </form>
                </div>
            </div>



    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->

            
            <div class="row">
                <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
                <div class="col-lg-7">
                    <div class="p-5">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Create a Location!</h1>
                        </div>

                        <form class="user" method="post" action="/location/create">
                            @csrf
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="text" class="form-control form-control-user" id=""
                                        placeholder="Name" name="name">
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id=""
                                            placeholder="Station Code" name="station_code">
                                    </div>
                                    
                                </div>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" placeholder="Address" name="address">
                            </div>
                            
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id=""
                                    placeholder="Location" name="location">
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id=""
                                    placeholder="Supervisor Name" name="supervisor_name">
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id=""
                                    placeholder="Phone number" name="phone_number">
                            </div>
                          
                             <button class="btn btn-primary btn-user btn-block" type="submit">
                                Add Location
                            </button>

                        </form>
                        
                    </div>
                </div>
            </div>

        </div>
    </div>


    <!-- Data -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Location Data</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Station Code</th>
                        <th>Location</th>
                        <th>Supervisor Name</th>
                        <th>Phone Number</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Station Code</th>
                        <th>Location</th>
                        <th>Supervisor Name</th>
                        <th>Phone Number</th>
                    </tr>
                </tfoot>
                <tbody>
                    @foreach($locations as $location)
                    <tr>
                        <td>{{$location->name}}</td>
                        <td>{{$location->address}}</td>
                        <td>{{$location->station_code}}</td>
                        <td>{{$location->location}}</td>
                        <td>{{$location->supervisor_name}}</td>
                        <td>{{$location->phone_number}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>


@endsection