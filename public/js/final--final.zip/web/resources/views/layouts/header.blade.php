 <!-- @if (Route::has('login'))
    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
        @auth
            <a href="{{ url('/dashboard') }}" class="text-sm text-gray-700 dark:text-gray-500 underline">Dashboard</a>
        @else
            <a href="{{ route('login') }}" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

            @if (Route::has('register'))
                <a href="{{ route('register') }}" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
            @endif
        @endauth
    </div>
@endif -->
<header class="header position-relative z-9">

    <nav class="navbar navbar-expand-lg fixed-top headroom">

        <div class="container position-relative">

            <a class="navbar-brand mr-lg-3" href="/">

                <img class="navbar-brand-dark" src="/img/logo/logo.png" alt="menuimage">

                <!-- <img class="navbar-brand-light" src="/img/logo/logo.png" alt="menuimage"> -->

            </a>

            <div class="navbar-collapse collapse" id="navbar-default-primary">

                <div class="navbar-collapse-header">

                    <div class="row">

                        <div class="col-6 collapse-brand">

                            <a href="#">

                                <img src="/img/logo/logo.png" alt="menuimage">

                            </a>

                        </div>

                        <div class="col-6 collapse-close">

                            <i class="fas fa-times" data-toggle="collapse" role="button"

                            data-target="#navbar-default-primary" aria-controls="navbar-default-primary"

                            aria-expanded="false" aria-label="Toggle navigation"></i>

                        </div>

                    </div>

                </div>

                <ul class="navbar-nav navbar-nav-hover ml-auto">


                    <li class="nav-item"><a class="nav-link" href="/">Home</a></li>


                    <li class="nav-item"><a class="nav-link" href="/about">About Us</a></li>


                    <li class="nav-item"><a class="nav-link" href="/services">Services</a></li>


                    <li class="nav-item"><a class="nav-link" href="/faq">FAQ's</a></li>


                    <li class="nav-item"><a class="nav-link" href="/contact-us">Contact Us</a></li>

                    @if (Auth::check())

                        <li class="nav-item">
                            <a class="nav-link">
                                <form method="POST" action="{{ route('logout') }}">
                                @csrf

                                    <x-responsive-nav-link :href="route('logout')"
                                            onclick="event.preventDefault();
                                                        this.closest('form').submit();">
                                        {{ __('Log Out') }}
                                    </x-responsive-nav-link>
                                </form>
                            </a>
                        </li>

               

                    @endif

                    

                </ul>

            </div>

            <div class="d-flex align-items-center">

                <button class="navbar-toggler ml-2" type="button" data-toggle="collapse" data-target="#navbar-default-primary" aria-controls="navbar-default-primary" aria-expanded="false" aria-label="Toggle navigation">

                    <span class="navbar-toggler-icon"></span>

                </button>

            </div>

        </div>

    </nav>

</header>

