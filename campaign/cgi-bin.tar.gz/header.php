      <section>
         <div class="land-full land-3-top-full">
            <div class="land-container">
               <div class="land-3-top">
                  <div class="land-3-top-logo">
                     <a href="/"><img src="images/VMPS-Logo-1.png"></a>
                  </div>
                  <div class="land-3-top-contact">
                     <ul>
                        <a style="color: black;" href="tel:<?php echo $mobile_number ?>">
                           <li>Phone: +91 <?php echo $mobile_number ?></li>
                        </a>
                        <li>Email: info@vikasmantra.org</li>
                        <li class="star" style="margin-left: 50px !important;"><i class="material-icons">star</i></li>
                        <li class="star"><i class="material-icons">star</i></li>
                        <li class="star"><i class="material-icons">star</i></li>
                        <li class="star"><i class="material-icons">star</i></li>
                        <li class="star"><i class="material-icons">star_half</i></li>
                        <li style="margin-left: 5px;">(50+ Google Reviews)</li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>