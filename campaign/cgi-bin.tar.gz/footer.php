<!-- COPY RIGHTS -->

<section>

    <div class="land-full land-1-foot-full">

        <div class="land-container">

           <div class="land-1-foot-text">

			<p>Copyrights © 2022. All rights reserved.</p>

		   </div>

		</div>

	</div>

</section>		